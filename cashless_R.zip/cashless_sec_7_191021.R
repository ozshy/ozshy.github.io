# cashless_sec_7_101021.R Section 7, cashless_55.tex 
# Note: Section 7.2 (counterfactuals) starts Line 490 (before that is just a prep), Section 7.1 (extensive intenstive margins) starts line 548
# cashless_counter_191015.R New Section 7: Counterfactuals and Margins. Separting R file from cashless_mult_xxxx.R. Mixed logit starts Line 788, counterfactual starts Line 1085
# cashless_mult_190930.R Section 6: Discrete choice random utility analysis. Note: This version cuts the <$50 and <$20 analysis. I also ADDED mixed logit (random coefficients). (see versions of the R-code before 190930 for previous versions of the paper: cashless_43.tex )
# cashless_main_190930.R Moving random utility (multinomial) analysis to a separte R-file

### The following packages are used:
library(formattable)# has percent function
#library(plotrix)# weighted histograms
library(dplyr)
library(xtable)# for LaTeX tables
#library(ggplot2)
#library(spatstat) # for weighted.median
#library(mfx)
#library(regclass) # for confusion_matrix
#library(nnet) # for multinomial logit
#library(AER) # for p-values of nnet multinom logit coeftest(regression)
library(mlogit)
#library(mnlogit)# Where I replicate the existing mlogit regressions and experiment with individual effects. 
#library(tibble)
setwd("~/Documents/Papers/cashless/cashless_coding")# NOTE, your working directory is different. Adjust accordingly!!! 
dir()

### Reading RDS datasets (merged data: merged by a separate R-file)
d1 = readRDS("cashless_merged_2017_2018_190928.rds")
objects()
names(d1)
### Data preparations
# NOTE: The paper itself (section-by-section) starts on line xxx

length(unique(d1$uasid)) # num of unique respondents
dim(d1) # num trans times num variables
#

## Restricting transactions to in-person only
names(d1)
dim(d1)
table(d1$in_person)
sum(is.na(d1$in_person))# how many NAs under in person
sum(!is.na(d1$in_person))# Not NAs in person
d2 = subset(d1,  in_person %in% 1)# restriction to in-person payments only
dim(d2)# num trans
length(unique(d2$uasid))# num of respondents (in-person only)
d2 = subset(d2,  type == "expenditure")# restriction expenditures only
dim(d2)# num trans
length(unique(d2$uasid))# num of respondents (in-person only)
# restricting to to expenditures only

## restricting to merchant type: 1:6 only
table(d2$merch)
d3 = subset(d2, merch %in% 1:7)# changed from 6 to 7 190927
# 1 - Grocery stores, convenience stores without gas stations, pharmacies
# 2 - Gas stations
# 3 - Sit-down restaurants and bars
# 4 - Fast food restaurants, coffee shops, cafeterias, food trucks
# 5 - General merchandise stores, department stores, other stores, online shopping
# 6 - General services: hair dressers, auto repair, parking lots, laundry or dry cleaning, etc.
# 7 - Arts, entertainment, recreation
dim(d3)# num transactions in merchants 1:7
length(unique(d3$uasid))# num respondents
d4 = d3 %>% filter(merch %in% 1:7) %>% droplevels()# delete unused levels (0s)
table(d4$merch)
sum(table(d4$merch))
#
## Examining and restricting to dominant payment instruments (PI)
# 0 - Multiple payment methods
# 1 - Cash
# 2 - Check
# 3 - Credit card
# 4 - Debit card
# 5 - Prepaid/gift/EBT card
table(d4$pi)# distribution of transactions by PI
percent(prop.table(table(d4$pi)))
dim(d4)
# Below, removing PI used less than 1%
d5 = subset(d4, pi %in% 1:5)
dim(d5)
length(unique(d5$uasid))
nrow(d5) - nrow(d4)# num payments lost by restricting PI
length(unique(d5$uasid)) - length(unique(d4$uasid)) # num respondents lost by restricting PI
table(d5$pi)
sum(table(d5$pi))# Number of trans 
length(unique(d5$uasid))# Number of respondents 
# Below, select only 4 used variables from the transaction dataset and xxx variables from the survey (adoption and assessments)
names(d5)
d6 = subset(d5, select = c("uasid", "weight_1", "weight_2", "amnt", "pi", "merch", "date", "hh_size", "age", "gender", "employed", "married", "education", "income", "year", "bnk_acnt_adopt", "chk_adopt", "cc_adopt", "dc_adopt", "svc_adopt", "assess_cost_cash", "assess_cost_check", "assess_cost_debit", "assess_cost_credit", "assess_cost_prepaid", "assess_acceptance_cash", "assess_acceptance_check", "assess_acceptance_debit", "assess_acceptance_credit", "assess_acceptance_prepaid", "assess_convenience_cash", "assess_convenience_check", "assess_convenience_debit", "assess_convenience_credit", "assess_convenience_prepaid", "assess_security_cash", "assess_security_check", "assess_security_debit", "assess_security_credit", "assess_security_prepaid", "assess_setup_cash", "assess_setup_check", "assess_setup_debit", "assess_setup_credit", "assess_setup_prepaid", "assess_record_cash", "assess_record_check", "assess_record_debit", "assess_record_credit", "assess_record_prepaid"))

# Below, give names to 5 PI (removing other PI levels)
table(d6$pi)
str(d6$pi)
head(d6$pi)
d7 = d6 %>% filter(pi %in% 1:5) %>% droplevels()# delete unused levels (0s)
table(d7$pi)
dim(d7)
levels(d7$pi)
d8 = d7
levels(d8$pi) =  c("cash", "check", "credit", "debit", "prepaid")
table(d8$pi)
dim(d8)

## adding var with respondent's adoption profile: Both_cards, DC_only, CC_only, None_banked, None_unb. Then, removing NAs. 
# Note: Adopt is first used in Figure 2 (not in any Table)
# Note: From cashless_190613b, changed adoption profile to match those in the tables. 
d9 = d8
table(d9$bnk_acnt_adopt)
length(unique(d9))
# num trans by banked and unbanked. 
unbanked_tran = subset(d9, bnk_acnt_adopt == 0)
nrow(unbanked_tran)# trans by unbanked
length(unique(unbanked_tran$uasid))# num of unbanked
length(unique(unbanked_tran$uasid))/length(unique(d9$uasid))# fraction of unbanked respondents
table(unbanked_tran$pi)# some inconsistency => need to redefine unbanked as those who also don't have credit and debit cards. Those who have debit card trans may have mistakenly stated that they don't have a bank account. 
#
d9$adopt[d9$dc_adopt==1 & d9$cc_adopt==1] = "Both_cards"
d9$adopt[d9$cc_adopt==0 & pi != "credit"] = "No_cc"
d9$adopt[d9$dc_adopt==0 & pi != "debit"] = "No_dc"
# d9$adopt[d9$dc_adopt==0 & d9$cc_adopt==0] = "None" # split below
d9$adopt[d9$dc_adopt==0 & d9$cc_adopt==0  & d9$bnk_acnt_adopt==1 & d9$pi != "credit" & d9$pi != "debit"] = "None_banked"
d9$adopt[d9$dc_adopt==0 & d9$cc_adopt==0  & d9$bnk_acnt_adopt==0 & d9$pi != "credit" & d9$pi != "debit"] = "None_unbanked"
table(d9$adopt)# trans vol vs. adoption 
d9$adopt = as.factor(d9$adopt)
levels(d9$adopt)
summary(d9$adopt)
#
# removing NAs from adopt
dim(d9)
d10 = d9[!is.na(d9$adopt), ]
dim(d10)
nrow(d10) - nrow(d9) # num trans lost be removing adopt==NA
d10_unique = d10[!duplicated(d10$uasid), ] # data set containing each resp only once (not to be used for trans stats, only adoption stats)
dim(d10_unique)
table(d10$adopt)# trans vol vs. adoption 

# simplifying variables for the regressions
# First do it for all trans. Later, restrict it to no_dc_cc only
inst5 = d10
inst5$paycash = 0# regression left side initialize paid w/ cards
inst5[inst5$pi == "cash", ]$paycash = 1# left side paid w/ cash
head(inst5$paycash, 10)
head(inst5$pi, 10)
table(inst5$paycash)
percent(prop.table(table(inst5$paycash)))# % of trans who pay cash
#
# Simplifying education (less levels) w/ a new variable "educ"
table(inst5$education)
str(inst5$education) 
inst5$education = as.integer(inst5$education) # change from factor to integer for the oprations below
inst5$educ = NA #new variable "educ" to simplfy education
inst5$educ[inst5$education <= 8] = "Elem_or_less"
inst5$educ[inst5$education >= 9 & inst5$education < 12] = "High_school"
inst5$educ[inst5$education >= 12 & inst5$education < 14] = "Assoc_or_college"
inst5$educ[inst5$education >= 14] = "MA_or_higher"
table(inst5$educ)
inst5$educ = factor(inst5$educ, levels = c("Elem_or_less", "High_school", "Assoc_or_college", "MA_or_higher")) #elem or less is ref
levels(inst5$educ)
table(inst5$educ)


inst6 = inst5
inst7 = inst6
# Reversing reverse) COST rating: 
# Before the change 1=highest cost 5=lowest cost (highest rating)
# After the change 1=lowest cost 5=highest cost (lowest rating). Now consistent with Figure 4
inst7$assess_cost_cash = 6 - inst6$assess_cost_cash
summary(inst7$assess_cost_cash)
inst7$assess_cost_check = 6 - inst6$assess_cost_check
summary(inst7$assess_cost_check)
inst7$assess_cost_debit = 6 - inst6$assess_cost_debit
summary(inst7$assess_cost_debit)
inst7$assess_cost_credit = 6 - inst6$assess_cost_credit
summary(inst7$assess_cost_credit)
inst7$assess_cost_prepaid = 6 - inst6$assess_cost_prepaid
summary(inst7$assess_cost_prepaid)
#

## NOTE: All the "cost_actual", "security_actual"... analysis is used only for the discussion in Section 5.1 showing that most respondents chose the PI with highest attributes. NOT used in the multinomial random utility model. 
table(inst7$assess_cost_cash)# rank dist by resp who paid with cash
table(inst7$assess_cost_check)
table(inst7$assess_cost_debit)
table(inst7$assess_cost_credit)
table(inst7$assess_cost_prepaid)
#
## Define "cost_actual" which will be the cost assessment of the respondent to the PI actually used (1:5). this is NOT dollar-valued! 
inst7$cost_actual = NA #initialize cost_actual
inst7[inst7$pi == "cash", ]$cost_actual = inst7[inst7$pi == "cash", ]$assess_cost_cash
inst7[inst7$pi == "check", ]$cost_actual = inst7[inst7$pi == "check", ]$assess_cost_check
inst7[inst7$pi == "debit", ]$cost_actual = inst7[inst7$pi == "debit", ]$assess_cost_debit
inst7[inst7$pi == "credit", ]$cost_actual = inst7[inst7$pi == "credit", ]$assess_cost_credit
inst7[inst7$pi == "prepaid", ]$cost_actual = inst7[inst7$pi == "prepaid", ]$assess_cost_prepaid
#
## Define "acceptance_actual" which will be the acceptance assessment of the respondent to the PI actually used (1:5). 5 = highest score (most accepted)
table(inst7$assess_acceptance_cash)
table(inst7$assess_acceptance_check)
table(inst7$assess_acceptance_debit)
table(inst7$assess_acceptance_credit)
table(inst7$assess_acceptance_prepaid)
#
inst7$acceptance_actual = NA #initialize acceptance_actual
inst7[inst7$pi == "cash", ]$acceptance_actual = inst7[inst7$pi == "cash", ]$assess_acceptance_cash
inst7[inst7$pi == "check", ]$acceptance_actual = inst7[inst7$pi == "check", ]$assess_acceptance_check
inst7[inst7$pi == "debit", ]$acceptance_actual = inst7[inst7$pi == "debit", ]$assess_acceptance_debit
inst7[inst7$pi == "credit", ]$acceptance_actual = inst7[inst7$pi == "credit", ]$assess_acceptance_credit
inst7[inst7$pi == "prepaid", ]$acceptance_actual = inst7[inst7$pi == "prepaid", ]$assess_acceptance_prepaid
#
## Define "convenience_actual" which will be the convenience  assessment of the respondent to the PI actually used (1:5). 5 = highest score (most convenient)
table(inst7$assess_convenience_cash)
table(inst7$assess_convenience_check)
table(inst7$assess_convenience_debit)
table(inst7$assess_convenience_credit)
table(inst7$assess_convenience_prepaid)
#
inst7$convenience_actual = NA #initialize _convenience_actual
inst7[inst7$pi == "cash", ]$convenience_actual = inst7[inst7$pi == "cash", ]$assess_convenience_cash
inst7[inst7$pi == "check", ]$convenience_actual = inst7[inst7$pi == "check", ]$assess_convenience_check
inst7[inst7$pi == "debit", ]$convenience_actual = inst7[inst7$pi == "debit", ]$assess_convenience_debit
inst7[inst7$pi == "credit", ]$convenience_actual = inst7[inst7$pi == "credit", ]$assess_convenience_credit
inst7[inst7$pi == "prepaid", ]$convenience_actual = inst7[inst7$pi == "prepaid", ]$assess_convenience_prepaid
#
## Define "security_actual" which will be the security  assessment of the respondent to the PI actually used (1:5) 5=highest score (most secure)
table(inst7$assess_security_cash)
table(inst7$assess_security_check)
table(inst7$assess_security_debit)
table(inst7$assess_security_credit)
table(inst7$assess_security_prepaid)
#
inst7$security_actual = NA #initialize _security_actual
inst7[inst7$pi == "cash", ]$security_actual = inst7[inst7$pi == "cash", ]$assess_security_cash
inst7[inst7$pi == "check", ]$security_actual = inst7[inst7$pi == "check", ]$assess_security_check
inst7[inst7$pi == "debit", ]$security_actual = inst7[inst7$pi == "debit", ]$assess_security_debit
inst7[inst7$pi == "credit", ]$security_actual = inst7[inst7$pi == "credit", ]$assess_security_credit
inst7[inst7$pi == "prepaid", ]$security_actual = inst7[inst7$pi == "prepaid", ]$assess_security_prepaid
#
## Define "record_actual" which will be the record  assessment of the respondent to the PI actually used (1:5) 5 = highest score (easiest to keep records)
table(inst7$assess_record_cash)
table(inst7$assess_record_check)
table(inst7$assess_record_debit)
table(inst7$assess_record_credit)
table(inst7$assess_record_prepaid)
#
inst7$record_actual = NA #initialize _record_actual
inst7[inst7$pi == "cash", ]$record_actual = inst7[inst7$pi == "cash", ]$assess_record_cash
inst7[inst7$pi == "check", ]$record_actual = inst7[inst7$pi == "check", ]$assess_record_check
inst7[inst7$pi == "debit", ]$record_actual = inst7[inst7$pi == "debit", ]$assess_record_debit
inst7[inst7$pi == "credit", ]$record_actual = inst7[inst7$pi == "credit", ]$assess_record_credit
inst7[inst7$pi == "prepaid", ]$record_actual = inst7[inst7$pi == "prepaid", ]$assess_record_prepaid
#
## Define "setup_actual" which will be the setup  assessment of the respondent to the PI actually used (1:5) 5 = highest score (easiest to set up)
table(inst7$assess_setup_cash)
table(inst7$assess_setup_check)
table(inst7$assess_setup_debit)
table(inst7$assess_setup_credit)
table(inst7$assess_setup_prepaid)
#
inst7$setup_actual = NA #initialize _setup_actual
inst7[inst7$pi == "cash", ]$setup_actual = inst7[inst7$pi == "cash", ]$assess_setup_cash
inst7[inst7$pi == "check", ]$setup_actual = inst7[inst7$pi == "check", ]$assess_setup_check
inst7[inst7$pi == "debit", ]$setup_actual = inst7[inst7$pi == "debit", ]$assess_setup_debit
inst7[inst7$pi == "credit", ]$setup_actual = inst7[inst7$pi == "credit", ]$assess_setup_credit
inst7[inst7$pi == "prepaid", ]$setup_actual = inst7[inst7$pi == "prepaid", ]$assess_setup_prepaid
#
names(inst7)
# verify that the assessements were correctly assigned to score for each PI
head(inst7[inst7$pi == "cash", c("cost_actual", "assess_cost_cash" , "pi", "acceptance_actual", "assess_acceptance_cash")])
head(inst7[inst7$pi == "check", c("cost_actual", "assess_cost_check", "pi", "acceptance_actual", "assess_acceptance_check")])
head(inst7[inst7$pi == "debit", c("cost_actual", "assess_cost_debit", "pi", "acceptance_actual", "assess_acceptance_debit")])
head(inst7[inst7$pi == "credit", c("cost_actual", "assess_cost_credit", "pi", "acceptance_actual", "assess_acceptance_credit")])
head(inst7[inst7$pi == "prepaid", c("cost_actual", "assess_cost_prepaid", "pi", "acceptance_actual", "assess_acceptance_prepaid")])
#
head(inst7[inst7$pi == "cash", c("acceptance_actual", "assess_acceptance_cash" , "pi", "convenience_actual", "assess_convenience_cash")])
head(inst7[inst7$pi == "check", c("acceptance_actual", "assess_acceptance_check", "pi", "convenience_actual", "assess_convenience_check")])
head(inst7[inst7$pi == "debit", c("acceptance_actual", "assess_acceptance_debit", "pi", "convenience_actual", "assess_convenience_debit")])
head(inst7[inst7$pi == "credit", c("acceptance_actual", "assess_acceptance_credit", "pi", "convenience_actual", "assess_convenience_credit")])
head(inst7[inst7$pi == "prepaid", c("acceptance_actual", "assess_acceptance_prepaid", "pi", "convenience_actual", "assess_convenience_prepaid")])
#
head(inst7[inst7$pi == "cash", c("setup_actual", "assess_setup_cash" , "pi", "record_actual", "assess_record_cash")])
head(inst7[inst7$pi == "check", c("setup_actual", "assess_setup_check", "pi", "record_actual", "assess_record_check")])
head(inst7[inst7$pi == "debit", c("setup_actual", "assess_setup_debit", "pi", "record_actual", "assess_record_debit")])
head(inst7[inst7$pi == "credit", c("setup_actual", "assess_setup_credit", "pi", "record_actual", "assess_record_credit")])
head(inst7[inst7$pi == "prepaid", c("setup_actual", "assess_setup_prepaid", "pi", "record_actual", "assess_record_prepaid")])
#
table(inst7$cost_actual)# This shows resp who did not choose to pay with the least-costly PI scored the highest
sum(table(inst7$cost_actual))# check sums up to total num trans
table(inst7$security_actual)# This shows resp who did not choose to pay with the PI
sum(table(inst7$security_actual))# check sums up to total num trans
table(inst7$acceptance_actual)#
sum(table(inst7$acceptance_actual))# check sums up to total num trans
table(inst7$convenience_actual)#
sum(table(inst7$convenience_actual))# check sums up to total num trans
table(inst7$setup_actual)#
table(inst7$record_actual)#
#
percent(table(inst7$cost_actual)/sum(table(inst7$cost_actual)))# Nice results, showing that 56.9% paid with the least costly, 20.5% second costly, 15.2% third clostly
percent(table(inst7$acceptance_actual)/sum(table(inst7$acceptance_actual)))# Nice results, 73.75% paid with the PI ranked highest for acceptance
percent(table(inst7$convenience_actual)/sum(table(inst7$convenience_actual)))# Nice results, 64.9% paid with the PI ranked *lowest* for acceptance
percent(table(inst7$security_actual)/sum(table(inst7$security_actual)))#  21% paid with the PI ranked most secured
percent(table(inst7$setup_actual)/sum(table(inst7$setup_actual)))#  45.7% paid with the PI ranked highest for setup
percent(table(inst7$record_actual)/sum(table(inst7$record_actual)))# Nice results, 42% paid with the PI ranked highest for acceptance
#
# Preparding for an xtable for the paper
(cost_actual_vec = as.vector(table(inst7$cost_actual)/sum(table(inst7$cost_actual)))) # converting table col to vec
(cost_security_vec = as.vector(table(inst7$security_actual)/sum(table(inst7$security_actual)))) # converting table col to vec
(cost_convenience_vec = as.vector(table(inst7$convenience_actual)/sum(table(inst7$cost_actual)))) # converting table col to vec
#
(assess.df = rbind(cost_actual_vec, cost_security_vec, cost_convenience_vec))
(colnames(assess.df) = c("1", "2", "3", "4", "5"))
assess.df
dim(assess.df)
str(assess.df)
assess.df2 = as.numeric(assess.df)

Assessment = c("Cost", "Security", "Convenience")
(assess.df3 = data.frame(cbind(Assessment, round(100*assess.df, digits = 2))))
dim(assess.df3)
str(assess.df3)
#
# below, create matrix w\ 1 extra column to indicate number of digits for each row
#(digitm = matrix(c(rep(0,1), rep(2,6)), nrow = 3, ncol = 7, byrow = T))
#
print(xtable(assess.df3, digits = 0), include.rownames = F, hline.after = c(0))


# End of assessment (also used in Section 5)

# Run this part first before mixed logit (uses the same data)
names(inst7)

allml =  subset(inst7, select = c(uasid, pi, amnt, income, assess_cost_cash, assess_cost_check, assess_cost_credit, assess_cost_debit, assess_cost_prepaid, assess_security_cash, assess_security_check, assess_security_credit, assess_security_debit, assess_security_prepaid, assess_convenience_cash, assess_convenience_check, assess_convenience_credit, assess_convenience_debit, assess_convenience_prepaid, cc_adopt, dc_adopt, svc_adopt, bnk_acnt_adopt )) 
names(allml)
# Remove 244 1.8% check transactions (see cashless_190731.R for all trans)
table(allml$pi)
percent(prop.table(table(allml$pi)))
nrow(allml)
allml =  subset(allml, pi != "check")
dim(allml)
table(allml$pi)
allml$pi = factor(allml$pi, levels = c("cash", "credit", "debit", "prepaid"))
table(allml$pi)
# remove NAs
any(is.na(allml))
dim(allml)
allml = na.omit(allml)
dim(allml)
#

## mlogit on none_unb (unbanked)
dim(allml)
noneunbml = na.omit(subset(allml, cc_adopt==0 & dc_adopt==0 & bnk_acnt_adopt==0 & pi != "credit" & pi != "debit"))
dim(noneunbml)
#
# now make it mlogit data (no cc & yes dc)
noneunbml_data = mlogit.data(noneunbml, choice = "pi", shape = "wide", id.var = "uasid", drop.index = F)
names(noneunbml_data)
head(noneunbml_data)
#
# add a column "cost" corresponding to respondent's assessment of each choice (including NOT chosen PI) (both)
noneunbml_data$cost = NA
noneunbml_data[noneunbml_data$alt=="cash", ]$cost = noneunbml_data[noneunbml_data$alt=="cash", ]$assess_cost_cash
# noneunbml_data[noneunbml_data$alt=="check", ]$cost = noneunbml_data[noneunbml_data$alt=="check", ]$assess_cost_check
noneunbml_data[noneunbml_data$alt=="debit", ]$cost = noneunbml_data[noneunbml_data$alt=="debit", ]$assess_cost_debit
noneunbml_data[noneunbml_data$alt=="credit", ]$cost = noneunbml_data[noneunbml_data$alt=="credit", ]$assess_cost_credit
noneunbml_data[noneunbml_data$alt=="prepaid", ]$cost = noneunbml_data[noneunbml_data$alt=="prepaid", ]$assess_cost_prepaid
# add a column "security" corresponding to respondent's assessment of each choice (including NOT chosen PI)
noneunbml_data$security = NA
noneunbml_data[noneunbml_data$alt=="cash", ]$security = noneunbml_data[noneunbml_data$alt=="cash", ]$assess_security_cash
# noneunbml_data[noneunbml_data$alt=="check", ]$security = noneunbml_data[noneunbml_data$alt=="check", ]$assess_security_check
noneunbml_data[noneunbml_data$alt=="debit", ]$security = noneunbml_data[noneunbml_data$alt=="debit", ]$assess_security_debit
noneunbml_data[noneunbml_data$alt=="credit", ]$security = noneunbml_data[noneunbml_data$alt=="credit", ]$assess_security_credit
noneunbml_data[noneunbml_data$alt=="prepaid", ]$security = noneunbml_data[noneunbml_data$alt=="prepaid", ]$assess_security_prepaid
# add a column "convenience" corresponding to respondent's assessment of each choice (including NOT chosen PI)
noneunbml_data$convenience = NA
noneunbml_data[noneunbml_data$alt=="cash", ]$convenience = noneunbml_data[noneunbml_data$alt=="cash", ]$assess_convenience_cash
#noneunbml_data[noneunbml_data$alt=="check", ]$convenience = noneunbml_data[noneunbml_data$alt=="check", ]$assess_convenience_check
noneunbml_data[noneunbml_data$alt=="debit", ]$convenience = noneunbml_data[noneunbml_data$alt=="debit", ]$assess_convenience_debit
noneunbml_data[noneunbml_data$alt=="credit", ]$convenience = noneunbml_data[noneunbml_data$alt=="credit", ]$assess_convenience_credit
noneunbml_data[noneunbml_data$alt=="prepaid", ]$convenience = noneunbml_data[noneunbml_data$alt=="prepaid", ]$assess_convenience_prepaid
#
# model to be estimated (none UNbanked)
noneunbmlmodel = mFormula( pi ~ cost + security + convenience | -1 ) # w/o adoption
noneunb_ml = mlogit(noneunbmlmodel, reflevel = "cash", alt.subset = c("cash", "check",  "prepaid"),  data = noneunbml_data)
summary(noneunb_ml)
(noneunbml_coef = as.vector(noneunb_ml$coefficients[1:3])) # cost, security, convenience
(noneunbml_pvalue = coef(summary(noneunb_ml))[,4]) # extract p-value
(noneunbml_pvalue = as.vector(noneunbml_pvalue)) # p-values vector
(noneunbml_sig = as.vector(symnum(noneunbml_pvalue, corr = FALSE, na = FALSE, cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1), symbols = c("***", "**", "*", ".", " ")))) # sig vector

## Computations of Consumer Surplus (CS) (None Unbanked)
# computing utility of cash, check, credit, debit, and prepaid 
#noneunbml$v_cash = 0 # estimated utility from paying cash = 0 (reference category, CHANGED 191015)
noneunbml$v_cash = NA # # estimated utility from paying cash
noneunbml$v_cash = noneunbml_coef[1]*noneunbml$assess_cost_cash + noneunbml_coef[2]*noneunbml$assess_security_cash + noneunbml_coef[3]*noneunbml$assess_convenience_cash 
#
# noneunbml$v_check = NA # estimated utility from paying check (removed)
# noneunbml$v_check = noneunbml_coef[1]*noneunbml$assess_cost_check + noneunbml_coef[2]*noneunbml$assess_security_check + noneunbml_coef[3]*noneunbml$assess_convenience_check 
#
noneunbml$v_credit = NA # # estimated utility from paying credit
noneunbml$v_credit = noneunbml_coef[1]*noneunbml$assess_cost_credit + noneunbml_coef[2]*noneunbml$assess_security_credit + noneunbml_coef[3]*noneunbml$assess_convenience_credit 

noneunbml$v_debit = NA # estimated utility from debit 
noneunbml$v_debit = noneunbml_coef[1]*noneunbml$assess_cost_debit + noneunbml_coef[2]*noneunbml$assess_security_debit + noneunbml_coef[3]*noneunbml$assess_convenience_debit 
#
noneunbml$v_prepaid = NA # estimated utility from paying prepaid
noneunbml$v_prepaid = noneunbml_coef[1]*noneunbml$assess_cost_prepaid + noneunbml_coef[2]*noneunbml$assess_security_prepaid + noneunbml_coef[3]*noneunbml$assess_convenience_prepaid 
#
head(noneunbml[, c("uasid", "pi", "v_cash", "v_credit", "v_debit", "v_prepaid")], 20)

# None: compute CS *before* the transition to cashless, based equation (3.10) on page 55 Train's book 
(mui = 1) # marginal utility of income = 1 (no use for that b/c only percentage change in CS is computed)
noneunbml$cs = mui*log(exp(noneunbml$v_cash) + 0 + 0 + 0 + exp(noneunbml$v_prepaid)) # cash is ref pi here
#
# CS *after* cash is phased out
noneunbml$cs_cashless =  mui*log(0 +0 +0 + exp(noneunbml$v_prepaid))
#
# Difference in CS (cashless - before)
noneunbml$cs_diff = noneunbml$cs_cashless - noneunbml$cs
# rate of change
noneunbml$cs_rate = noneunbml$cs_diff/noneunbml$cs
#
length(noneunbml$cs)
summary(noneunbml$cs) # CS before the change
summary(noneunbml$cs_cashless) # CS after stores become cashless
summary(noneunbml$cs_diff)
summary(noneunbml$cs_rate)
(noneunbml_loss_rate_med = median(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_avg = mean(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_q25 = quantile(-1*noneunbml$cs_rate, 0.25, na.rm = T))
(noneunbml_loss_rate_q75 = quantile(-1*noneunbml$cs_rate, 0.75, na.rm = T))
(noneunbml_loss_rate_min = min(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_max = max(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_q75 = quantile(-1*noneunbml$cs_rate, 0.75, na.rm = T))
(noneunbml_loss_rate_sd = sd(-1*noneunbml$cs_rate, na.rm = T))
#head(noneunbml[, c("pi", "cs", "cs_cashless", "cs_diff", "cs_rate")])

### Redo all above with mixed logit (random coefficients) 

# model to be estimated (none unbanked)
noneunbmlmodel = mFormula( pi ~ cost + security + convenience | -1 ) # w/o adoption
noneunb_ml = mlogit(noneunbmlmodel, alt.subset = c("cash", "check",  "prepaid"), rpar = c(cost = "zbt", security = "t", convenience = "t"),  data = noneunbml_data)# ln, cn do not work! t=triangular dist, n=normal
summary(noneunb_ml)
(noneunbml_coef = as.vector(noneunb_ml$coefficients[1:3])) # cost, security, convenience
(noneunbml_pvalue = coef(summary(noneunb_ml))[,4]) # extract p-value
(noneunbml_pvalue = as.vector(noneunbml_pvalue)) # p-values vector
(noneunbml_sig = as.vector(symnum(noneunbml_pvalue, corr = FALSE, na = FALSE, cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1), symbols = c("***", "**", "*", ".", " ")))) # sig vector

## Computations of Consumer Surplus (CS) (None Unbanked)
# computing utility of cash, check, credit, debit, and prepaid 
#noneunbml$v_cash = 0 # estimated utility from paying cash = 0 (reference category, CHANGED 191015)
noneunbml$v_cash = NA # # estimated utility from paying cash
noneunbml$v_cash = noneunbml_coef[1]*noneunbml$assess_cost_cash + noneunbml_coef[2]*noneunbml$assess_security_cash + noneunbml_coef[3]*noneunbml$assess_convenience_cash 

#
# noneunbml$v_check = NA # estimated utility from paying check (removed)
# noneunbml$v_check = noneunbml_coef[1]*noneunbml$assess_cost_check + noneunbml_coef[2]*noneunbml$assess_security_check + noneunbml_coef[3]*noneunbml$assess_convenience_check 
#
noneunbml$v_credit = NA # # estimated utility from paying credit
noneunbml$v_credit = noneunbml_coef[1]*noneunbml$assess_cost_credit + noneunbml_coef[2]*noneunbml$assess_security_credit + noneunbml_coef[3]*noneunbml$assess_convenience_credit 

noneunbml$v_debit = NA # estimated utility from debit 
noneunbml$v_debit = noneunbml_coef[1]*noneunbml$assess_cost_debit + noneunbml_coef[2]*noneunbml$assess_security_debit + noneunbml_coef[3]*noneunbml$assess_convenience_debit 
#
noneunbml$v_prepaid = NA # estimated utility from paying prepaid
noneunbml$v_prepaid = noneunbml_coef[1]*noneunbml$assess_cost_prepaid + noneunbml_coef[2]*noneunbml$assess_security_prepaid + noneunbml_coef[3]*noneunbml$assess_convenience_prepaid 
#
head(noneunbml[, c("uasid", "pi", "v_cash", "v_credit", "v_debit", "v_prepaid")], 20)

# None: compute CS *before* the transition to cashless, based equation (3.10) on page 55 Train's book 
(mui = 1) # marginal utility of income = 1 (no use for that b/c only percentage change in CS is computed)
noneunbml$cs = mui*log(exp(noneunbml$v_cash) + 0 + 0 + 0 + exp(noneunbml$v_prepaid)) # cash is ref pi here
#
# CS *after* cash is phased out
noneunbml$cs_cashless =  mui*log(0 +0 +0 + exp(noneunbml$v_prepaid))
#
# Difference in CS (cashless - before)
noneunbml$cs_diff = noneunbml$cs_cashless - noneunbml$cs
# rate of change
noneunbml$cs_rate = noneunbml$cs_diff/noneunbml$cs
#
length(noneunbml$cs)
summary(noneunbml$cs) # CS before the change
summary(noneunbml$cs_cashless) # CS after stores become cashless
summary(noneunbml$cs_diff)
summary(noneunbml$cs_rate)
(noneunbml_loss_rate_med = median(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_avg = mean(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_q25 = quantile(-1*noneunbml$cs_rate, 0.25, na.rm = T))
(noneunbml_loss_rate_q75 = quantile(-1*noneunbml$cs_rate, 0.75, na.rm = T))
(noneunbml_loss_rate_min = min(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_max = max(-1*noneunbml$cs_rate, na.rm = T))
(noneunbml_loss_rate_sd = sd(-1*noneunbml$cs_rate, na.rm = T))
#head(noneunbml[, c("pi", "cs", "cs_cashless", "cs_diff", "cs_rate")])

### Section 7.2: Counterfactual analysis: How change in CS is affected if the cost of prepaid card is reduced. Analysis of None Unbanked with no cc and no dc
# First, suppose the cost of PP cards is reduced to the cost of cash
# The data to be used

# New data for none unbanked assuming that the cost of prepaid is the same as the cost of cash
# None: compute CS *before* the transition to cashless, based equation (3.10) on page 55 Train's book 
(mui = 1) # marginal utility of income = 1 (no use for that b/c only percentage change in CS is computed)
noneunbml$cs = mui*log(exp(noneunbml$v_cash) + 0 + 0 + 0 + exp(noneunbml$v_prepaid)) # cash is ref pi here
summary(noneunbml$cs)# CS before
#
# CS *after* cash is phased out
counter1 = noneunbml
dim(counter1)
summary(counter1$v_cash)# 
#noneunbml$cs_cashless =  mui*log(0 +0 +0 + exp(noneunbml$v_prepaid))
# Now assume that the utility after cashless is the utility of cash assuming that the features of cash are mimiced by pp cards
counter1$cs_cashless =  mui*log(0+ 0 +0 +0 + exp(counter1$v_cash))
summary(counter1$cs_cashless)
#
# Difference in CS (cashless - before)
counter1$cs_diff = counter1$cs_cashless - noneunbml$cs
# rate of change
counter1$cs_rate = counter1$cs_diff/noneunbml$cs
#
length(counter1$cs)
summary(noneunbml$cs) # CS before the change
summary(counter1$cs_cashless) # CS after stores become cashless
summary(counter1$cs_diff)
summary(counter1$cs_rate)
(counter1_loss_rate_med = median(-1*counter1$cs_rate, na.rm = T))# reported in paper
(counter1_loss_rate_avg = mean(-1*counter1$cs_rate, na.rm = T))# reported in paper
(counter1_loss_rate_q25 = quantile(-1*counter1$cs_rate, 0.25, na.rm = T))
(counter1_loss_rate_q75 = quantile(-1*counter1$cs_rate, 0.75, na.rm = T))
(counter1_loss_rate_min = min(-1*counter1$cs_rate, na.rm = T))
(counter1_loss_rate_max = max(-1*counter1$cs_rate, na.rm = T))
(counter1_loss_rate_sd = sd(-1*counter1$cs_rate, na.rm = T))

# Discussion of assessments by none unbanked
names(noneunbml)
dim(noneunbml)
length(unique(noneunbml$uasid))
none_unb_resp = noneunbml[!duplicated(noneunbml$uasid),]# remove duplicated respondents
dim(none_unb_resp)
#
summary(none_unb_resp$assess_cost_cash)# reported in paper
summary(none_unb_resp$assess_cost_prepaid)# reported in paper
#
summary(none_unb_resp$assess_security_cash)# reported in paper
summary(none_unb_resp$assess_security_prepaid)# reported in paper
#
summary(none_unb_resp$assess_convenience_cash)# reported in paper
summary(none_unb_resp$assess_convenience_prepaid)# reported in paper
#
table(counter1$pi)
percent(prop.table(table(counter1$pi)
))

### Section 7.1: Intensive vs. extensive margin w.r.t pp cards
names(noneunbml)
nrow(noneunbml)# num payments
length(unique(noneunbml$uasid))# num trans
nrow(none_unb_resp)# num trans
percent(prop.table(table(none_unb_resp$svc_adopt)))# % resp w/o and w/ pp cards
table(none_unb_resp$svc_adopt)# resp numbers

no_pp_trans = subset(noneunbml, svc_adopt == 0)# trans by unbanked with no cards and no pp cards
nrow(no_pp_trans)
#
yes_pp_trans = subset(noneunbml, svc_adopt == 1)# trans by unbanked with no cards but yes pp cards
nrow(yes_pp_trans)
#
nrow(no_pp_trans) + nrow(yes_pp_trans)
#
## Analysis of no pp card 
# now make it mlogit data (no cc & yes dc)
no_pp_data = mlogit.data(no_pp_trans, choice = "pi", shape = "wide", id.var = "uasid", drop.index = F)
names(no_pp_data)
head(no_pp_data)
#
# add a column "cost" corresponding to respondent's assessment of each choice (including NOT chosen PI) (both)
no_pp_data$cost = NA
no_pp_data[no_pp_data$alt=="cash", ]$cost = no_pp_data[no_pp_data$alt=="cash", ]$assess_cost_cash
# no_pp_data[no_pp_data$alt=="check", ]$cost = no_pp_data[no_pp_data$alt=="check", ]$assess_cost_check
no_pp_data[no_pp_data$alt=="debit", ]$cost = no_pp_data[no_pp_data$alt=="debit", ]$assess_cost_debit
no_pp_data[no_pp_data$alt=="credit", ]$cost = no_pp_data[no_pp_data$alt=="credit", ]$assess_cost_credit
no_pp_data[no_pp_data$alt=="prepaid", ]$cost = no_pp_data[no_pp_data$alt=="prepaid", ]$assess_cost_prepaid
# add a column "security" corresponding to respondent's assessment of each choice (including NOT chosen PI)
no_pp_data$security = NA
no_pp_data[no_pp_data$alt=="cash", ]$security = no_pp_data[no_pp_data$alt=="cash", ]$assess_security_cash
# no_pp_data[no_pp_data$alt=="check", ]$security = no_pp_data[no_pp_data$alt=="check", ]$assess_security_check
no_pp_data[no_pp_data$alt=="debit", ]$security = no_pp_data[no_pp_data$alt=="debit", ]$assess_security_debit
no_pp_data[no_pp_data$alt=="credit", ]$security = no_pp_data[no_pp_data$alt=="credit", ]$assess_security_credit
no_pp_data[no_pp_data$alt=="prepaid", ]$security = no_pp_data[no_pp_data$alt=="prepaid", ]$assess_security_prepaid
# add a column "convenience" corresponding to respondent's assessment of each choice (including NOT chosen PI)
no_pp_data$convenience = NA
no_pp_data[no_pp_data$alt=="cash", ]$convenience = no_pp_data[no_pp_data$alt=="cash", ]$assess_convenience_cash
#no_pp_data[no_pp_data$alt=="check", ]$convenience = no_pp_data[no_pp_data$alt=="check", ]$assess_convenience_check
no_pp_data[no_pp_data$alt=="debit", ]$convenience = no_pp_data[no_pp_data$alt=="debit", ]$assess_convenience_debit
no_pp_data[no_pp_data$alt=="credit", ]$convenience = no_pp_data[no_pp_data$alt=="credit", ]$assess_convenience_credit
no_pp_data[no_pp_data$alt=="prepaid", ]$convenience = no_pp_data[no_pp_data$alt=="prepaid", ]$assess_convenience_prepaid
# model to be estimated (none unbanked no cc no dc and no pp cards)
no_ppmodel = mFormula( pi ~ cost + security + convenience | -1 ) # w/o adoption
no_pp_ml = mlogit(no_ppmodel, alt.subset = c("cash", "check",  "prepaid"), rpar = c(cost = "zbt", security = "t", convenience = "t"),  data = no_pp_data)# ln, cn do not work! t=triangular dist, n=normal
summary(no_pp_ml)
(no_pp_coef = as.vector(noneunb_ml$coefficients[1:3])) # cost, security, convenience
(no_pp_pvalue = coef(summary(noneunb_ml))[,4]) # extract p-value
(no_pp_pvalue = as.vector(no_pp_pvalue)) # p-values vector
(no_pp_sig = as.vector(symnum(no_pp_pvalue, corr = FALSE, na = FALSE, cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1), symbols = c("***", "**", "*", ".", " ")))) # sig vector

## Computations of Consumer Surplus (CS) (None Unbanked)
# computing utility of cash, check, credit, debit, and prepaid 
#no_pp$v_cash = 0 # estimated utility from paying cash = 0 (reference category, CHANGED 191015)
no_pp_trans$v_cash = NA # # estimated utility from paying cash
no_pp_trans$v_cash = no_pp_coef[1]*no_pp_trans$assess_cost_cash + no_pp_coef[2]*no_pp_trans$assess_security_cash + no_pp_coef[3]*no_pp_trans$assess_convenience_cash 

#
# no_pp$v_check = NA # estimated utility from paying check (removed)
# no_pp$v_check = no_pp_coef[1]*no_pp$assess_cost_check + no_pp_coef[2]*no_pp$assess_security_check + no_pp_coef[3]*no_pp$assess_convenience_check 
#
no_pp_trans$v_credit = NA # # estimated utility from paying credit
no_pp_trans$v_credit = no_pp_coef[1]*no_pp_trans$assess_cost_credit + no_pp_coef[2]*no_pp_trans$assess_security_credit + no_pp_coef[3]*no_pp_trans$assess_convenience_credit 

no_pp_trans$v_debit = NA # estimated utility from debit 
no_pp_trans$v_debit = no_pp_coef[1]*no_pp_trans$assess_cost_debit + no_pp_coef[2]*no_pp_trans$assess_security_debit + no_pp_coef[3]*no_pp_trans$assess_convenience_debit 
#
no_pp_trans$v_prepaid = NA # estimated utility from paying prepaid
no_pp_trans$v_prepaid = no_pp_coef[1]*no_pp_trans$assess_cost_prepaid + no_pp_coef[2]*no_pp_trans$assess_security_prepaid + no_pp_coef[3]*no_pp_trans$assess_convenience_prepaid 
#
head(no_pp_trans[, c("uasid", "pi", "v_cash", "v_credit", "v_debit", "v_prepaid")], 20)

# None: compute CS *before* the transition to cashless, based equation (3.10) on page 55 Train's book 
(mui = 1) # marginal utility of income = 1 (no use for that b/c only percentage change in CS is computed)
no_pp_trans$cs = mui*log(exp(no_pp_trans$v_cash) + 0 + 0 + 0 + exp(no_pp_trans$v_prepaid)) # cash is ref pi here
#
# CS *after* cash is phased out
no_pp_trans$cs_cashless =  mui*log(0 +0 +0 + exp(no_pp_trans$v_prepaid))
#
# Difference in CS (cashless - before)
no_pp_trans$cs_diff = no_pp_trans$cs_cashless - no_pp_trans$cs
# rate of change
no_pp_trans$cs_rate = no_pp_trans$cs_diff/no_pp_trans$cs
#
length(no_pp_trans$cs)
summary(no_pp_trans$cs) # CS before the change
summary(no_pp_trans$cs_cashless) # CS after stores become cashless
summary(no_pp_trans$cs_diff)
summary(no_pp_trans$cs_rate)
(no_pp_trans_loss_rate_med = median(-1*no_pp_trans$cs_rate, na.rm = T))# reported in paper
(no_pp_trans_loss_rate_avg = mean(-1*no_pp_trans$cs_rate, na.rm = T))# reported in paper
(no_pp_trans_loss_rate_q25 = quantile(-1*no_pp_trans$cs_rate, 0.25, na.rm = T))
(no_pp_trans_loss_rate_q75 = quantile(-1*no_pp_trans$cs_rate, 0.75, na.rm = T))
(no_pp_trans_loss_rate_min = min(-1*no_pp_trans$cs_rate, na.rm = T))
(no_pp_trans_loss_rate_max = max(-1*no_pp_trans$cs_rate, na.rm = T))
(no_pp_trans_loss_rate_sd = sd(-1*no_pp_trans$cs_rate, na.rm = T))
#head(noneunbml[, c("pi", "cs", "cs_cashless", "cs_diff", "cs_rate")])

## repeat change in CS for yes pp card
## Analysis of YES pp card 
# now make it mlogit data (no cc & yes dc)
yes_pp_data = mlogit.data(yes_pp_trans, choice = "pi", shape = "wide", id.var = "uasid", drop.index = F)
names(yes_pp_data)
head(yes_pp_data)
#
# add a column "cost" corresponding to respondent's assessment of each choice (including NOT chosen PI) (both)
yes_pp_data$cost = NA
yes_pp_data[yes_pp_data$alt=="cash", ]$cost = yes_pp_data[yes_pp_data$alt=="cash", ]$assess_cost_cash
# yes_pp_data[yes_pp_data$alt=="check", ]$cost = yes_pp_data[yes_pp_data$alt=="check", ]$assess_cost_check
yes_pp_data[yes_pp_data$alt=="debit", ]$cost = yes_pp_data[yes_pp_data$alt=="debit", ]$assess_cost_debit
yes_pp_data[yes_pp_data$alt=="credit", ]$cost = yes_pp_data[yes_pp_data$alt=="credit", ]$assess_cost_credit
yes_pp_data[yes_pp_data$alt=="prepaid", ]$cost = yes_pp_data[yes_pp_data$alt=="prepaid", ]$assess_cost_prepaid
# add a column "security" corresponding to respondent's assessment of each choice (including NOT chosen PI)
yes_pp_data$security = NA
yes_pp_data[yes_pp_data$alt=="cash", ]$security = yes_pp_data[yes_pp_data$alt=="cash", ]$assess_security_cash
# yes_pp_data[yes_pp_data$alt=="check", ]$security = yes_pp_data[yes_pp_data$alt=="check", ]$assess_security_check
yes_pp_data[yes_pp_data$alt=="debit", ]$security = yes_pp_data[yes_pp_data$alt=="debit", ]$assess_security_debit
yes_pp_data[yes_pp_data$alt=="credit", ]$security = yes_pp_data[yes_pp_data$alt=="credit", ]$assess_security_credit
yes_pp_data[yes_pp_data$alt=="prepaid", ]$security = yes_pp_data[yes_pp_data$alt=="prepaid", ]$assess_security_prepaid
# add a column "convenience" corresponding to respondent's assessment of each choice (including NOT chosen PI)
yes_pp_data$convenience = NA
yes_pp_data[yes_pp_data$alt=="cash", ]$convenience = yes_pp_data[yes_pp_data$alt=="cash", ]$assess_convenience_cash
#yes_pp_data[yes_pp_data$alt=="check", ]$convenience = yes_pp_data[yes_pp_data$alt=="check", ]$assess_convenience_check
yes_pp_data[yes_pp_data$alt=="debit", ]$convenience = yes_pp_data[yes_pp_data$alt=="debit", ]$assess_convenience_debit
yes_pp_data[yes_pp_data$alt=="credit", ]$convenience = yes_pp_data[yes_pp_data$alt=="credit", ]$assess_convenience_credit
yes_pp_data[yes_pp_data$alt=="prepaid", ]$convenience = yes_pp_data[yes_pp_data$alt=="prepaid", ]$assess_convenience_prepaid
# model to be estimated (none unbanked no cc no dc and no pp cards)
yes_ppmodel = mFormula( pi ~ cost + security + convenience | -1 ) # w/o adoption
yes_pp_ml = mlogit(yes_ppmodel, alt.subset = c("cash", "check",  "prepaid"), rpar = c(cost = "zbt", security = "t", convenience = "t"),  data = yes_pp_data)# ln, cn do not work! t=triangular dist, n=normal
summary(yes_pp_ml)
(yes_pp_coef = as.vector(noneunb_ml$coefficients[1:3])) # cost, security, convenience
(yes_pp_pvalue = coef(summary(noneunb_ml))[,4]) # extract p-value
(yes_pp_pvalue = as.vector(yes_pp_pvalue)) # p-values vector
(yes_pp_sig = as.vector(symnum(yes_pp_pvalue, corr = FALSE, na = FALSE, cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1), symbols = c("***", "**", "*", ".", " ")))) # sig vector

## Computations of Consumer Surplus (CS) (None Unbanked)
# computing utility of cash, check, credit, debit, and prepaid 
#yes_pp$v_cash = 0 # estimated utility from paying cash = 0 (reference category, CHANGED 191015)
yes_pp_trans$v_cash = NA # # estimated utility from paying cash
yes_pp_trans$v_cash = yes_pp_coef[1]*yes_pp_trans$assess_cost_cash + yes_pp_coef[2]*yes_pp_trans$assess_security_cash + yes_pp_coef[3]*yes_pp_trans$assess_convenience_cash 

#
# yes_pp$v_check = NA # estimated utility from paying check (removed)
# yes_pp$v_check = yes_pp_coef[1]*yes_pp$assess_cost_check + yes_pp_coef[2]*yes_pp$assess_security_check + yes_pp_coef[3]*yes_pp$assess_convenience_check 
#
yes_pp_trans$v_credit = NA # # estimated utility from paying credit
yes_pp_trans$v_credit = yes_pp_coef[1]*yes_pp_trans$assess_cost_credit + yes_pp_coef[2]*yes_pp_trans$assess_security_credit + yes_pp_coef[3]*yes_pp_trans$assess_convenience_credit 

yes_pp_trans$v_debit = NA # estimated utility from debit 
yes_pp_trans$v_debit = yes_pp_coef[1]*yes_pp_trans$assess_cost_debit + yes_pp_coef[2]*yes_pp_trans$assess_security_debit + yes_pp_coef[3]*yes_pp_trans$assess_convenience_debit 
#
yes_pp_trans$v_prepaid = NA # estimated utility from paying prepaid
yes_pp_trans$v_prepaid = yes_pp_coef[1]*yes_pp_trans$assess_cost_prepaid + yes_pp_coef[2]*yes_pp_trans$assess_security_prepaid + yes_pp_coef[3]*yes_pp_trans$assess_convenience_prepaid 
#
head(yes_pp_trans[, c("uasid", "pi", "v_cash", "v_credit", "v_debit", "v_prepaid")], 20)

# None: compute CS *before* the transition to cashless, based equation (3.10) on page 55 Train's book 
(mui = 1) # marginal utility of income = 1 (no use for that b/c only percentage change in CS is computed)
yes_pp_trans$cs = mui*log(exp(yes_pp_trans$v_cash) + 0 + 0 + 0 + exp(yes_pp_trans$v_prepaid)) # cash is ref pi here
#
# CS *after* cash is phased out
yes_pp_trans$cs_cashless =  mui*log(0 +0 +0 + exp(yes_pp_trans$v_prepaid))
#
# Difference in CS (cashless - before)
yes_pp_trans$cs_diff = yes_pp_trans$cs_cashless - yes_pp_trans$cs
# rate of change
yes_pp_trans$cs_rate = yes_pp_trans$cs_diff/yes_pp_trans$cs
#
length(yes_pp_trans$cs)
summary(yes_pp_trans$cs) # CS before the change
summary(yes_pp_trans$cs_cashless) # CS after stores become cashless
summary(yes_pp_trans$cs_diff)
summary(yes_pp_trans$cs_rate)
(yes_pp_trans_loss_rate_med = median(-1*yes_pp_trans$cs_rate, na.rm = T))# reported in paper
(yes_pp_trans_loss_rate_avg = mean(-1*yes_pp_trans$cs_rate, na.rm = T))# reported in paper
(yes_pp_trans_loss_rate_q25 = quantile(-1*yes_pp_trans$cs_rate, 0.25, na.rm = T))
(yes_pp_trans_loss_rate_q75 = quantile(-1*yes_pp_trans$cs_rate, 0.75, na.rm = T))
(yes_pp_trans_loss_rate_min = min(-1*yes_pp_trans$cs_rate, na.rm = T))
(yes_pp_trans_loss_rate_max = max(-1*yes_pp_trans$cs_rate, na.rm = T))
(yes_pp_trans_loss_rate_sd = sd(-1*yes_pp_trans$cs_rate, na.rm = T))
#head(noneunbml[, c("pi", "cs", "cs_cashless", "cs_diff", "cs_rate")])


########### End of cashless_mult_date.R

