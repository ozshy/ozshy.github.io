# read_data.R Revised 180513 
# Purpose: Reading and editing the raw data (CSV from Boston Fed)
# Note: For variable definitions see the diary 2016 codebook (PDF from Boston Fed's website)
# To be saved as diary2016_data.rds before actual analysis begins
# 
setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding") # Set working directory on your computer
# Your working directory would be different from the above !!!
dir()
# Now, download the raw data CSV file from Boston Fed's website:
# https://www.bostonfed.org/publications/diary-of-consumer-payment-choice/2016-diary.aspx 
#
diary0=read.csv("dcpc-2016-public-data.csv")
# The above reads original data you downloaded from Bos Fed 
# (rename the csv file to match the above)
dim(diary0)
names(diary0)
#
# Build partial list of demographic variables of interest
demog0 = c("work_employed", "marital_status","highest_education", 
           "race_white","race_black","race_asian", "race_other",
           "hh_size", "income_hh","homeowner","male","age")
# Note: "highest_education_gfk" ignored b/c it came from a different survey and generates many NAs in some variables.
# Note: All work_xxx variables have been deleted except work_employed 
length(demog0)# no of selected demographic variables
#
# Build partial list of transaction variables of interest
trans0 = c("amnt","pi","merch","submerch","in_person")
length(trans0)# Number of selected transaction-related variables
#
# Combining demog and trans columns into a data frame
diary1 = diary0[, colnames(diary0) %in% c(trans0, demog0)]
dim(diary1)
names(diary1)
#
# Subsetting to retail store or only transactions only
diary2 = subset(diary1, merch==7)
dim(diary2)
diary2 = subset(diary2, select = -c(merch)) # Remove column "merch
#
# Subsetting to in-person transactions only
diary3 = subset(diary2, in_person==1)
dim(diary3)
diary3 = subset(diary3, select = -c(in_person))

# Search and delete NAs (except for submerch, later called Buy)
sapply(diary3, function(x) sum(is.na(x)))
# delete NAs from hh_size
diary3 = diary3[complete.cases(diary3[,"work_employed"]),]
dim(diary3)
# what else is missing?
sapply(diary3, function(x) sum(is.na(x)))
diary3 = diary3[complete.cases(diary3[, "hh_size"]),] # deleting NAs from hh_size
sapply(diary3, function(x) sum(is.na(x)))
#
# deleting NA from income_hh
diary3 = diary3[complete.cases(diary3[,"income_hh"]),]
dim(diary3)
sapply(diary3, function(x) sum(is.na(x)))
#
diary3 = diary3[complete.cases(diary3[,"age"]),]
dim(diary3)
#
sapply(diary3, function(x) sum(is.na(x))) # Which columns still have NAs
diary3 = diary3[complete.cases(diary3[,"pi"]),] #delete NAs from "pi
sapply(diary3, function(x) sum(is.na(x))) # Which columns still have NAs
diary3 = diary3[complete.cases(diary3[,"race_white"]),]
sapply(diary3, function(x) sum(is.na(x))) # Which columns still have NAs
# Only submerch has NAs. Submerch is not used for demographic analysis
#
diary4 = diary3 # Only "suberch" has NAs (category not used for most of the paper)
names(diary4)
str(diary4)
#
# Renaming column variable names ("nicer" names to be displayed on trees)
diary10 = diary4
colnames(diary10)
colnames(diary10)[colnames(diary10)=="amnt"] = "Amount"
#
colnames(diary10)[colnames(diary10)=="pi"] = "Method"
diary10$Method[diary10$Method == 0] = "Multiple" # More than one payment method
diary10$Method[diary10$Method == 1] = "Cash"
diary10$Method[diary10$Method == 2] = "Check"
diary10$Method[diary10$Method == 3] = "Ccard"
diary10$Method[diary10$Method == 4] = "Dcard"
diary10$Method[diary10$Method == 5] = "Pcard"
diary10$Method[diary10$Method == 6] = "Deduct" #authorized deduction
diary10$Method[diary10$Method == 7] = "OBBP" #online banking bill payment
diary10$Method[diary10$Method == 8] = "Morder" # Money order
diary10$Method[diary10$Method == 9] = "Tcheck" # Traveler's check
diary10$Method[diary10$Method == 10] = "PayPal"
diary10$Method[diary10$Method == 11] = "A2A" #account-to-account transfer
diary10$Method[diary10$Method == 12] = "Mobile"
diary10$Method[diary10$Method == 13] = "Other"
diary10$Method[diary10$Method == 14] = "DedInc" # Deduction from income
head(diary10)
# Reset the levels of Methods, so cash is the reference level
diary10$Method = factor(diary10$Method, levels = 
                          c("Cash", "Ccard",  "Dcard", "Pcard", "Check", "Morder", "Mobile", "Multiple",
                            "A2A", "DedInc", "Deduct", "OBBP", "Other", "PayPal"))
table(diary10$Method)
# 
colnames(diary10)[colnames(diary10) == "submerch"] = "Spend" # Rename submerch as spend (for spending type)
# The list below could be consolidated into fewer spending types
diary10$Spend[diary10$Spend == 1] = "Doctor"
diary10$Spend[diary10$Spend == 2] = "Hospital"
diary10$Spend[diary10$Spend == 3] = "Pharma"
diary10$Spend[diary10$Spend == 4] = "Insurance"
diary10$Spend[diary10$Spend == 5] = "Grocery"
diary10$Spend[diary10$Spend == 6] = "Fast_food"
diary10$Spend[diary10$Spend == 7] = "Coffee_shop"
diary10$Spend[diary10$Spend == 8] = "Restaurant"
diary10$Spend[diary10$Spend == 9] = "Bar"
diary10$Spend[diary10$Spend == 10] = "Gas"
diary10$Spend[diary10$Spend == 11] = "Conv_store"
diary10$Spend[diary10$Spend == 12] = "Lg_retailer"
diary10$Spend[diary10$Spend == 13] = "Home_impv"
diary10$Spend[diary10$Spend == 14] = "OL_retailer"
diary10$Spend[diary10$Spend == 15] = "Liquor"
diary10$Spend[diary10$Spend == 16] = "Pet_store"
diary10$Spend[diary10$Spend == 17] = "Auto_rent_lease"
diary10$Spend[diary10$Spend == 18] = "Auto_dealer"
diary10$Spend[diary10$Spend == 19] = "Clothing"
diary10$Spend[diary10$Spend == 20] = "Dept_and_disc_stores"
diary10$Spend[diary10$Spend == 21] = "Furn_appl_elec_sores"
diary10$Spend[diary10$Spend == 22] = "Mail"
diary10$Spend[diary10$Spend == 23] = "Rental_pl"
diary10$Spend[diary10$Spend == 24] = "Movie"
diary10$Spend[diary10$Spend == 25] = "OL_shopping"
diary10$Spend[diary10$Spend == 26] = "News"
diary10$Spend[diary10$Spend == 27] = "Other_store"
diary10$Spend[diary10$Spend == 29] = "Pers_care"
diary10$Spend[diary10$Spend == 30] = "Tuition"
diary10$Spend[diary10$Spend == 31] = "Employ_serv"
diary10$Spend[diary10$Spend == 32] = "Repair"
diary10$Spend[diary10$Spend == 33] = "Vending"
diary10$Spend[diary10$Spend == 34] = "Vet"
diary10$Spend[diary10$Spend == 35] = "Entertain"
diary10$Spend[diary10$Spend == 36] = "Movie"
diary10$Spend[diary10$Spend == 37] = "Legal_prof_serv"
diary10$Spend[diary10$Spend == 38] = "Hotel"
diary10$Spend[diary10$Spend == 39] = "Rent"
diary10$Spend[diary10$Spend == 40] = "Home_contractors"
diary10$Spend[diary10$Spend == 41] = "Building_serv"
diary10$Spend[diary10$Spend == 42] = "Sport_events"
diary10$Spend[diary10$Spend == 43] = "Gambling"
diary10$Spend[diary10$Spend == 44] = "Auto_maint"
head(diary10)   
#
colnames(diary10)[colnames(diary10) == "work_employed"] = "Work"
diary10$Work[diary10$Work == 1] = "Employed"
diary10$Work[diary10$Work == 0] = "Not_empl"
diary10$Work = factor(diary10$Work) # Levels OK: "Employed" "Not_empl"
levels(diary10$Work)
table(diary10$Work)
#
# Below, replacing marital_status with Marital with 4 levels only
diary10$Marital[diary10$marital_status == 1 | diary10$marital_status == 2] = "Married"
diary10$Marital[diary10$marital_status == 3 | diary10$marital_status == 4] = "Div_sep"
diary10$Marital[diary10$marital_status == 5] = "Widowed"
diary10$Marital[diary10$marital_status == 6] = "Never_mar"
table(diary10$marital_status)
diary10$Marital = factor(diary10$Marital, levels = c("Never_mar", "Married", "Div_sep", "Widowed"))
table(diary10$Marital)
diary10 = subset(diary10, select = -c(marital_status)) # delete column
str(diary10)
#
#colnames(diary10)[colnames(diary10) == "highest_education"] = "Educ"
table(diary10$highest_education) # Below, I refer to earning a degree and not to years of study
diary10$Educ[diary10$highest_education <= 8] = "Elem_or_less"
diary10$Educ[diary10$highest_education >= 9 & diary10$highest_education < 12] = "High"
diary10$Educ[diary10$highest_education >= 12 & diary10$highest_education < 14] = "Assoc_or_college"
diary10$Educ[diary10$highest_education >= 14] = "MA+"
table(diary10$Educ)
diary10 = subset(diary10, select = -c(highest_education)) 
diary10$Educ = factor(diary10$Educ, levels = 
                        c("Elem_or_less", "High", "Assoc_or_college", "MA+")) #elem or less is ref
levels(diary10$Educ)
table(diary10$Educ)
#    
# Consolidating race into a single column: "Race"
diary10$Race = NA 
diary10$Race[diary10$race_white == 1] = "White"   
diary10$Race[diary10$race_black == 1] = "Black"
diary10$Race[diary10$race_asian == 1] = "Asian"
diary10$Race[diary10$race_other == 1] = "Other"
table(diary10$Race)
dim(diary10)
colnames(diary10)
diary10 = subset(diary10, select = -c(race_white,race_black,race_asian,race_other)) # deleting
dim(diary10)
diary10$Race = factor(diary10$Race, levels = c("White", "Black", "Asian", "Other"))
table(diary10$Race)
# 
colnames(diary10)[colnames(diary10) == "hh_size"] = "HH_size" # Renaming
table(diary10$HH_size)
colnames(diary10)[colnames(diary10) == "income_hh"] = "HH_income" # Renaming
table(diary10$HH_income)
# 
#Redefining & reducing income categories
#
diary11 = diary10
diary11$HH_income[diary10$HH_income <= 7] = "0<25k"
diary11$HH_income[diary10$HH_income > 7 & diary10$HH_income <=11 ] = "25<50k"
diary11$HH_income[diary10$HH_income > 11 & diary10$HH_income <=13 ] = "50<75k"
diary11$HH_income[diary10$HH_income > 13 & diary10$HH_income <=14 ] = "75<100k"
diary11$HH_income[diary10$HH_income > 14 & diary10$HH_income <=15 ] = "100<125k"
diary11$HH_income[diary10$HH_income > 15 & diary10$HH_income <=16 ] = "125<200k"
diary11$HH_income[diary10$HH_income > 16 & diary10$HH_income <=17 ] = "200<500k"
diary11$HH_income[diary10$HH_income > 17 & diary10$HH_income <=18 ] = ">500k"
table(diary11$HH_income)
diary11$HH_income = factor(diary11$HH_income, levels = 
      c("0<25k", "25<50k", "50<75k", "75<100k", "100<125k", "125<200k", "200<500k", ">500k"))# <25k is the ref level
table(diary11$HH_income)
#
colnames(diary11)[colnames(diary11) == "homeowner"] = "House"
diary11$House[diary11$House == 0] = "Not-own"   
diary11$House[diary11$House == 1] = "Own"
table(diary11$House)
diary11$House = factor(diary11$House, levels = c("Not-own", "Own"))# Not-own is ref
#
colnames(diary11)[colnames(diary11) == "age"] = "Age"
summary(diary11$Age)
#
colnames(diary11)[colnames(diary11) == "male"] = "Gender"
diary11$Gender[diary11$Gender == 0] = "Female"
diary11$Gender[diary11$Gender == 1] = "Male"
table(diary11$Gender)
diary11$Gender = factor(diary11$Gender, levels = c("Male", "Female"))# Male is ref
table(diary11$Gender)
#
colnames(diary11)
sapply(diary11, function(x) sum(is.na(x))) # Verify no missing NAs (except for "Spend")
# 
# Set factors variables to factors and set factor levels
diary12 = diary11
str(diary12)
#
diary12$Spend = factor(diary12$Spend) # Too many levels, need consolidation
str(diary12)
#
# Saving edited data to be used for coding in the analysis
diary2016_data = diary12 #smaller data with reduced levels
# setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding")# Folder with R-codes
saveRDS(diary2016_data, "diary2016_data.rds") # Saving into the R-code folder
# Use this file to start any analysis of the paper.
dir()
#
### End of reading data ### 

