# multinom.R Section 3.3: Multinomial logit (lower part of Table 1)
# Revised 180513
# Packages used for this coding: 
library("xtable") # For exporting to LaTeX
library(nnet) # for multinomial logit (not using mlogit b/c it requires data formatting)
#
setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding") # Set working directory on your computer
# Your working directory would be different from the above !!!
dir()
diary=readRDS("diary2016_data.rds")# read edited data
dim(diary)
names(diary)
str(diary)
# I need to delete transaction with methods used less than 1%
100*round(table(diary$Method)/length(diary$Method), digits = 4) #percent
# Choose the 5 most widely used payment methods (> 1% use)
diary=diary[diary$Method=="Cash" | diary$Method=="Ccard" 
            | diary$Method=="Dcard" | diary$Method=="Pcard" | diary$Method=="Check", ]
dim(diary)# 
table(diary$Method)# still need to remove the attributes of unused payment methods
diary$Method = factor(diary$Method)# This removes unused factor levels of deleted Methods
str(diary$Method)
table(diary$Method)
#
# Splitting data into training and testing (not needed for rpart b/c rpart uses CV)
set.seed(1)
index_train = sample(1:nrow(diary), size=0.8*nrow(diary), replace = F)
length(index_train) 
diary_train = diary[index_train, ]# 80% of diary
diary_test = diary[-index_train, ]# 20% of diary
#
# Defining regression model (for multinomial estimation): 
method_on_demog = Method~Amount+Age+HH_size+Work+Marital+HH_income+House+Gender+Race # Educ removed
#
method_multinom=multinom(method_on_demog, data = diary_train)
summary(method_multinom) #Coeff are not marginal effects (hard to do with multinom)
# 
# #Figuring out p-values (nnet multinom does not compute p-values)
# z=summary(method_multinom)$coefficients/summary(method_multinom)$standard.errors #z-values
# p=(1-pnorm(abs(z),0,1))*2 #2-tailed test p-values
# round(p, digits=4) #not used in the paper
#
# Start predictions on tesing data
method_demog_multi_pred = predict(method_multinom, diary_test, type = "class")# This predicts payment instruments
length(method_demog_multi_pred)
length(diary_test$Method)
head(method_demog_multi_pred)
# method_multinom_prob=predict(method_multinom, diary_test, type = "probs")# predicts probabilities of use
# method_multinom_prob=as.data.frame(method_multinom_pred)
# names(method_multinom_prob)
# head(method_multinom_prob)
# dim(method_multinom_prob)
#
# Creating confusion table for multilogit (middle part of Table 1)
method_demog_multi_table=table(method_demog_multi_pred, diary_test$Method, dnn = c("Predict","Actual"))
method_demog_multi_table # confusion table
#
# General stats for the middle part of Table 1 (multinomial)
# Goal, to present this table at the bottom of the multinomial confusion matrix
dim(method_demog_multi_table)# before the loop, need to know table dimension
method_demog_multi_correct=0# Initialize 
for(i in 1:5){method_demog_multi_correct= method_demog_multi_correct + method_demog_multi_table[i,i]}
# method_demog_multi_correct #correct prediction on the table (sum diagonal)
# method_demog_multi_correct/nrow(diary_test)#frac of correct predictions
# (method_demog_multi_table[1,1]+method_demog_multi_table[2,2])/
#   (method_demog_multi_table[1,1]+method_demog_multi_table[2,2]
#    +(method_demog_multi_table[2,1]+method_demog_multi_table[1,2]))#frac correct for cash and credit
#
# Table to be appended below the confusion table
method_demog_error = data.frame("Cash" = c(NA,NA,NA), "Ccard" = c(NA,NA,NA), "Dcard" = c(NA,NA,NA), "Pcard" = c(NA,NA,NA), "Check" = c(NA,NA,NA))
row.names(method_demog_error) = c("Total actual", "Correct predictions", "Correct rate (%)")
# 1st row: Total actual
(method_demog_error[1, "Cash"] = length(diary_test$Method[diary_test$Method == "Cash"]))# Actual cash trans
(method_demog_error[1, "Ccard"] = length(diary_test$Method[diary_test$Method == "Ccard"]))# Actual Ccard trans
(method_demog_error[1, "Dcard"] = length(diary_test$Method[diary_test$Method == "Dcard"]))# Actual Dcard trans
(method_demog_error[1, "Pcard"] = length(diary_test$Method[diary_test$Method == "Pcard"]))# Actual Pcard trans
(method_demog_error[1, "Check"] = length(diary_test$Method[diary_test$Method == "Check"]))# Actual Check trans
# 2nd row: No. correct predictions (%) [true positive rate]
(method_demog_error[2, "Cash"] =   method_demog_multi_table[1,1])
(method_demog_error[2, "Ccard"] =  method_demog_multi_table[2,2])
(method_demog_error[2, "Dcard"] =  method_demog_multi_table[3,3])
(method_demog_error[2, "Pcard"] =  method_demog_multi_table[4,4])
(method_demog_error[2, "Check"] =  method_demog_multi_table[5,5])
# 3rd row: Correct predictions (%) [true positive rate]
(method_demog_error[3, "Cash"] =   100*method_demog_multi_table[1,1]/method_demog_error[1, "Cash"])
(method_demog_error[3, "Ccard"] =  100*method_demog_multi_table[2,2]/method_demog_error[1, "Ccard"])
(method_demog_error[3, "Dcard"] =  100*method_demog_multi_table[3,3]/method_demog_error[1, "Dcard"])
(method_demog_error[3, "Pcard"] =  100*method_demog_multi_table[4,4]/method_demog_error[1, "Pcard"])
(method_demog_error[3, "Check"] =  100*method_demog_multi_table[5,5]/method_demog_error[1, "Check"])
#
round(method_demog_error, digits = 0) # To be appended to the bottom of the confusion matrix
#
# Converting the above 2 tables to LaTeX:
xtable(method_demog_multi_table) # confusion table
xtable(method_demog_error, digits = 0) # Stat to append at the bottom of confusion table

### End of multinomial logit (section 3.3) ###

### Below is not used in the paper (multinomial with 4 dummies)
### Repeat with the 4 dummies suggested by the tree
#
## Introducing 4 dummies: (motivated by the tree)
diary$d_amt10 = 0
diary$d_amt10[diary$Amount > 10] = 1 # transaction value more than $10
diary$d_amt20 = 0
diary$d_amt20[diary$Amount > 20] = 1 # transaction value more than $10
diary$d_age36 = 0
diary$d_age36[diary$Age > 36 & diary$Age <=64 ] =1
diary$d_age64 = 0
diary$d_age64[diary$Age > 64] = 1
head(diary)
tail(diary)
#
# Splitting data into training and testing (not needed for rpart b/c rpart uses CV)
set.seed(1)
index_train = sample(1:nrow(diary), size=0.8*nrow(diary), replace = F)
length(index_train) 
diary_train = diary[index_train, ]# 80% of diary
diary_test = diary[-index_train, ]# 20% of diary
#
# Regression model revised with dummies
method_on_demog_d = Method~Amount+Age+HH_size+Work+Marital+Educ+HH_income+House+Gender+Race+d_amt10++d_amt20+d_age36+d_age64
#
method_multinom_d = multinom(method_on_demog_d, data = diary_train)
# summary(method_multinom_d) #Coeff are not marginal effects (hard to do with multinom)
#
method_demog_multi_pred_d = predict(method_multinom_d, diary_test, type = "class")# This predicts payment instruments
#method_multinom_pred_d=predict(method_multinom_d, diary_test, type = "probs")#predicts probabilities of use
# method_multinom_prob_d=as.data.frame(method_multinom_pred_d)
# names(method_multinom_prob_d)
# head(method_multinom_prob_d)
# dim(method_multinom_prob_d)
#
# Creating confusion table 
head(method_demog_multi_pred_d)
length(method_demog_multi_pred_d)
length(diary_test$Method)
method_demog_multi_table_d=table(method_demog_multi_pred_d, diary_test$Method, dnn = c("Predict","Actual"))
method_demog_multi_table_d # confusion table
#
# General stats generated by this table (discussed in the paper)
# Goal, to present this table next to the tree confusion matrix
dim(method_demog_multi_table_d)# before the loop, need to know table dimension
method_demog_multi_correct_d=0# Initialize 
for(i in 1:5){method_demog_multi_correct_d= method_demog_multi_correct_d + method_demog_multi_table_d[i,i]}
# method_demog_multi_correct_d #correct prediction on the table (sum diagonal)
# method_demog_multi_correct_d/nrow(diary_test)#frac of correct predictions
# (method_demog_multi_table_d[1,1]+method_demog_multi_table_d[2,2])/
#   (method_demog_multi_table_d[1,1]+method_demog_multi_table_d[2,2]
#    +(method_demog_multi_table_d[2,1]+method_demog_multi_table_d[1,2]))#frac correct for cash and credit
#
# Table to be appended below the confusion table
method_demog_error_d = data.frame("Cash" = c(NA,NA,NA), "Ccard" = c(NA,NA,NA), "Dcard" = c(NA,NA,NA), "Pcard" = c(NA,NA,NA), "Check" = c(NA,NA,NA))
row.names(method_demog_error_d) = c("Total actual", "Correct predictions", "Correct rate (%)")
# 1st row: Total actual
(method_demog_error_d[1, "Cash"] = length(diary_test$Method[diary_test$Method == "Cash"]))# Actual cash trans
(method_demog_error_d[1, "Ccard"] = length(diary_test$Method[diary_test$Method == "Ccard"]))# Actual Ccard trans
(method_demog_error_d[1, "Dcard"] = length(diary_test$Method[diary_test$Method == "Dcard"]))# Actual Dcard trans
(method_demog_error_d[1, "Pcard"] = length(diary_test$Method[diary_test$Method == "Pcard"]))# Actual Pcard trans
(method_demog_error_d[1, "Check"] = length(diary_test$Method[diary_test$Method == "Check"]))# Actual Check trans
# 2nd row: No. correct predictions (%) [true positive rate]
(method_demog_error_d[2, "Cash"] =   method_demog_multi_table_d[1,1])
(method_demog_error_d[2, "Ccard"] =  method_demog_multi_table_d[2,2])
(method_demog_error_d[2, "Dcard"] =  method_demog_multi_table_d[3,3])
(method_demog_error_d[2, "Pcard"] =  method_demog_multi_table_d[4,4])
(method_demog_error_d[2, "Check"] =  method_demog_multi_table_d[5,5])
# 3rd row: Correct predictions (%) [true positive rate]
(method_demog_error_d[3, "Cash"] =   100*method_demog_multi_table_d[1,1]/method_demog_error_d[1, "Cash"])
(method_demog_error_d[3, "Ccard"] =  100*method_demog_multi_table_d[2,2]/method_demog_error_d[1, "Ccard"])
(method_demog_error_d[3, "Dcard"] =  100*method_demog_multi_table_d[3,3]/method_demog_error_d[1, "Dcard"])
(method_demog_error_d[3, "Pcard"] =  100*method_demog_multi_table_d[4,4]/method_demog_error_d[1, "Pcard"])
(method_demog_error_d[3, "Check"] =  100*method_demog_multi_table_d[5,5]/method_demog_error_d[1, "Check"])
#
round(method_demog_error_d, digits = 0)
#
# Converting the above 2 tables to LaTeX:
xtable(method_demog_multi_table_d) # confusion table
xtable(method_demog_error_d, digits = 0) # Stat to append at the bottom of confusion table
#
# End of multinomial logit