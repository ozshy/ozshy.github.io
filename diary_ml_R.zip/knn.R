# knn.R Section 5: k-nearest neighbors (repalcing Clustering analysis)
# Revised 180519
# library(ggplot2) # for plotting 
# theme_set(theme_bw())# White background for plots 
library(class) #for knn
library(xtable) # converts tables to LaTeX
#
setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding") # Set working directory on your computer
# Your working directory would be different from the above !!!
dir()
diary=readRDS("diary2016_data.rds")# read edited data
dim(diary)
names(diary)
str(diary)
# I need to delete transaction with methods used less than 1%
100*round(table(diary$Method)/length(diary$Method), digits = 4) #percent
#
# Choose the 5 most widely used payment methods (> 1% use)
# Now limit payment methods to Cash, Ccard, and Dcard
diary = diary[diary$Method=="Cash" | diary$Method=="Ccard" | diary$Method=="Dcard" | diary$Method=="Pcard" | diary$Method=="Check", ]
diary$Method = factor(diary$Method) # Deletes unused factors
table(diary$Method)
#
# knn (and clustering) works with numerical features (not factors)
# Below, convert HH_income to numerical values by taking the average in each category
table(diary$HH_income)
# Below, refers to the reduced income categories: diary2016sm.rds
# Create a new feature (column) called "Income"
diary$Income = 0
diary$Income[diary$HH_income == "0<25k"]    = 12500
diary$Income[diary$HH_income == "25<50k"]   = 37500
diary$Income[diary$HH_income == "50<75k"]   = 62500
diary$Income[diary$HH_income == "75<100k"]  = 87500
diary$Income[diary$HH_income == "100<125k"] = 112500
diary$Income[diary$HH_income == "125<200k"] = 162500
diary$Income[diary$HH_income == "200<500k"] = 350000
diary$Income[diary$HH_income == ">500k"]    = 500000
#
# Splitting diary into training and testing 
set.seed(1) # Same seed as other parts the paper
index_train = sample(1:nrow(diary), size=0.8*nrow(diary), replace = F)
length(index_train) 
diary_train = diary[index_train, ]# 80% of diarym
diary_test = diary[-index_train, ]# 20% of diarym
#
head(diary_train)
head(diary_test)
# Create a vector of train data Method (needed for knn)
diary_train_method = diary_train$Method # A vector of training method
length(diary_train_method)
table(diary_train_method)
diary_test_method = diary_test$Method # A vector of test method
length(diary_test_method)
table(diary_test_method)
#
# Reduce the number of features numerical valued only (also ignoring HH_size) 
# knn does not work with categorical features unless distance is meaningful
# Also, delete "Method" for which the above vectors will be used
knn_train=subset(diary_train, select = c("Amount", "Age", "Income"))
knn_test=subset(diary_test, select = c("Amount", "Age", "Income"))
head(knn_train)
head(knn_test)
dim(knn_train)
dim(knn_test)
nrow(knn_train) + nrow(knn_test) # Sample size
#
### knn for all 5 payment instruments
# Constructing confusion matrix to be included in Table 1
# knn starts here, first just "testing" for k=10 (non-optimal k)
# Note: 1st entry is training data, 2nd is test data, 3rd is classification vector (Cash, Dcard, Others)
knn_10 = knn(knn_train, knn_test, diary_train_method, k = 10)
summary(knn_10)
tail(knn_10) # predicted
tail(diary_test_method) # actual
sum(diary_test_method != knn_10)/length(diary_test_method) # high error rate (non-optimal k)
#
# Find the optimal (error-reducing) k
(knn_seq = rep(1,40)) # initialize before loop (k between 1 and 40)
for(i in 1:40) {
  ki = knn(knn_train, knn_test, diary_train_method, k = i);
  knn_seq[i]=sum(diary_test_method != ki)/length(diary_test_method) # error rate
}
knn_seq # Error rates for each k between 1 and 40
min(knn_seq) # Find the smallest error rate
(kmin = which(knn_seq == min(knn_seq))) # gives the k corresonding to min error rate
#
knn_min = knn(knn_train, knn_test, diary_train_method, k = kmin) # kNN w/ optimal k
#
# Start confusion matrix for knn w/ 5 payment methods (bottom of table 1)
(knn_table = table(knn_min, diary_test_method, dnn = c("Predict","Actual")))
#
# Table to be appended below the confusion table (knn)
method_demog_error = data.frame("Cash" = c(NA,NA,NA), "Ccard" = c(NA,NA,NA), "Dcard" = c(NA,NA,NA), "Pcard" = c(NA,NA,NA), "Check" = c(NA,NA,NA))
row.names(method_demog_error) = c("Total actual", "Correct predictions", "Correct rate (%)")
# 1st row: Total actual
(method_demog_error[1, "Cash"]  = length(diary_test$Method[diary_test$Method == "Cash"]))# Actual cash trans
(method_demog_error[1, "Ccard"] = length(diary_test$Method[diary_test$Method == "Ccard"]))# Actual Ccard trans
(method_demog_error[1, "Dcard"] = length(diary_test$Method[diary_test$Method == "Dcard"]))# Actual Dcard trans
(method_demog_error[1, "Pcard"] = length(diary_test$Method[diary_test$Method == "Pcard"]))# Actual Pcard trans
(method_demog_error[1, "Check"] = length(diary_test$Method[diary_test$Method == "Check"]))# Actual Check trans
# 2nd row: No. correct predictions (%) [true positive rate]
(method_demog_error[2, "Cash"] =   knn_table[1,1])
(method_demog_error[2, "Ccard"] =  knn_table[2,2])
(method_demog_error[2, "Dcard"] =  knn_table[3,3])
(method_demog_error[2, "Pcard"] =  knn_table[4,4])
(method_demog_error[2, "Check"] =  knn_table[5,5])
# 3rd row: Correct predictions (%) [true positive rate]
(method_demog_error[3, "Cash"] =   100*knn_table[1,1]/method_demog_error[1, "Cash"])
(method_demog_error[3, "Ccard"] =  100*knn_table[2,2]/method_demog_error[1, "Ccard"])
(method_demog_error[3, "Dcard"] =  100*knn_table[3,3]/method_demog_error[1, "Dcard"])
(method_demog_error[3, "Pcard"] =  100*knn_table[4,4]/method_demog_error[1, "Pcard"])
(method_demog_error[3, "Check"] =  100*knn_table[5,5]/method_demog_error[1, "Check"])
#
round(method_demog_error, digits = 0) # To be appended to the bottom of the confusion matrix
#
# Converting the above 2 tables to LaTeX:
xtable(knn_table) # confusion table
xtable(method_demog_error, digits = 0) # Stats to append at the bottom of confusion table
#
######################
### Plot knn predictions for "Cash" "Other" only (Figure 6)
# Plot mismatch on the test data. will Need to limit to $25, otherwise hard to see
# plot actual test data: Cash and Other (c or o), 
# but color according to predictions (red and blue) to visualize mismatch. 
table(knn_min)
# Below, convert knn predictions to cash vs other
knn_min2 = ifelse(knn_min == "Cash", "Cash", "Other") 
table(knn_min2)
# Below, convert actual test data methods to cash vs other
table(diary_test_method)
diary_test_method2 = ifelse(diary_test_method == "Cash", "Cash", "Other") # actual test 
table(diary_test_method2)
#
# Plot actual test data C (cash) in red, O (other) in blue (0 to $25) [Fig.4 Left]
plot(diary_test[c("Age","Amount")], pch=c("c","o")[as.factor(diary_test_method2)], 
     col=c("red", "blue")[as.factor(diary_test_method2)], ylim=range(0:25), 
     ylab="Payment dollar amount")
#
# Plot actual test data C (cash), O (other) (0 to $25) [Fig.4 Right]
# but, color corresponds to knn predictions: Cash in Red, Other in Blue
plot(diary_test[c("Age","Amount")], pch=c("c","o")[as.factor(diary_test_method2)], 
     col=c("red", "blue")[as.factor(knn_min2)], ylim=range(0:25), 
     ylab="Payment dollar amount")
#
### End of knn R code ###

