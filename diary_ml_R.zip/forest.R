# forest.R Section 4: Random Forest (Section 4)
# Revised 180513
# Packages used for this coding: 
# rpart packages instead of the tree package which allows multiple reponses >2
#Random forests 
library("randomForest")
library("xtable") #exporting to LaTeX
#
setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding") # Set working directory on your computer
# Your working directory would be different from the above !!!
dir()
diary=readRDS("diary2016_data.rds")# read edited data
dim(diary)
names(diary)
str(diary)
# I need to delete transaction with methods used less than 1%
100*round(table(diary$Method)/length(diary$Method), digits = 4) #percent
# Choose the 5 most widely used payment methods (> 1% use)
diary=diary[diary$Method=="Cash" | diary$Method=="Ccard" 
            | diary$Method=="Dcard" | diary$Method=="Pcard" | diary$Method=="Check", ]
dim(diary)
table(diary$Method)# still need to remove the attributes of unused payment methods
diary$Method = factor(diary$Method)# This removes unused factor levels of deleted Methods
str(diary$Method)
table(diary$Method)
#
# Splitting data into training and testing 
set.seed(1)
index_train = sample(1:nrow(diary), size=0.8*nrow(diary), replace = F)
length(index_train) 
diary_train = diary[index_train, ]# 80% of diary
diary_test = diary[-index_train, ]# 20% of diary
#
#defining model
method_on_demog = Method~Amount+Age+HH_size+Work+Marital+HH_income+House+Gender+Race # Educ removed
#
#First, entire data is used for visualization, creating variable importance plot
method_on_demog_rf=randomForest(method_on_demog, data=diary, mtry=3, importance=T)
importance(method_on_demog_rf) # Table of variable importance
# Below, Plot of variable importance (displayed in paper)
varImpPlot(method_on_demog_rf, type = 1, main ='' )#default type 1&2, 
#
#Now, use only training data to prepare prediction
method_on_demog_rf=randomForest(method_on_demog, data=diary_train, mtry=3, importance=T)
#importance(method_on_demog_rf) # Table of variable importance
#varImpPlot(method_on_demog_rf) # Plot of variable importance (not displayed in paper)
#
#Start predictions and building confusion matrix (bottom of Table 1)
method_on_demog_rf_pred=predict(method_on_demog_rf, newdata = diary_test)# predict test data
(method_on_demog_rf_table=table(method_on_demog_rf_pred, diary_test$Method, dnn = c("Predict","Actual")))
#
# Table to be appended below the confusion table (random forest)
method_demog_error = data.frame("Cash" = c(NA,NA,NA), "Ccard" = c(NA,NA,NA), "Dcard" = c(NA,NA,NA), "Pcard" = c(NA,NA,NA), "Check" = c(NA,NA,NA))
row.names(method_demog_error) = c("Total actual", "Correct predictions", "Correct rate (%)")
# 1st row: Total actual
(method_demog_error[1, "Cash"]  = length(diary_test$Method[diary_test$Method == "Cash"]))# Actual cash trans
(method_demog_error[1, "Ccard"] = length(diary_test$Method[diary_test$Method == "Ccard"]))# Actual Ccard trans
(method_demog_error[1, "Dcard"] = length(diary_test$Method[diary_test$Method == "Dcard"]))# Actual Dcard trans
(method_demog_error[1, "Pcard"] = length(diary_test$Method[diary_test$Method == "Pcard"]))# Actual Pcard trans
(method_demog_error[1, "Check"] = length(diary_test$Method[diary_test$Method == "Check"]))# Actual Check trans
# 2nd row: No. correct predictions (%) [true positive rate]
(method_demog_error[2, "Cash"] =   method_on_demog_rf_table[1,1])
(method_demog_error[2, "Ccard"] =  method_on_demog_rf_table[2,2])
(method_demog_error[2, "Dcard"] =  method_on_demog_rf_table[3,3])
(method_demog_error[2, "Pcard"] =  method_on_demog_rf_table[4,4])
(method_demog_error[2, "Check"] =  method_on_demog_rf_table[5,5])
# 3rd row: Correct predictions (%) [true positive rate]
(method_demog_error[3, "Cash"] =   100*method_on_demog_rf_table[1,1]/method_demog_error[1, "Cash"])
(method_demog_error[3, "Ccard"] =  100*method_on_demog_rf_table[2,2]/method_demog_error[1, "Ccard"])
(method_demog_error[3, "Dcard"] =  100*method_on_demog_rf_table[3,3]/method_demog_error[1, "Dcard"])
(method_demog_error[3, "Pcard"] =  100*method_on_demog_rf_table[4,4]/method_demog_error[1, "Pcard"])
(method_demog_error[3, "Check"] =  100*method_on_demog_rf_table[5,5]/method_demog_error[1, "Check"])
#
round(method_demog_error, digits = 0) # To be appended to the bottom of the confusion matrix
#
# Converting the above 2 tables to LaTeX:
xtable(method_on_demog_rf_table) # confusion table
xtable(method_demog_error, digits = 0) # Stats to append at the bottom of confusion table
#
### End of forest.R ###