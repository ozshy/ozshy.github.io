There are 7 R-code files, and one data file "diary2016_data.rds."

The R-code file "read-data.R" is the only R script file that reads the original CSV data. The original CSV can be downloaded directly from the Boston Fed's website: https://www.bostonfed.org/publications/diary-of-consumer-payment-choice/2016-diary.aspx
This R-code "read-data.R" edits the raw CSV file and saves it as an R data file "diary2016_data.rds" (which serves as the benchmark data file for all the 6 R-scripts listed below).  

The following 6 R-script files use only "diary2016_data.rds" for data (and not the raw CSV). Make sure that you place all data and R-scripts in the same directory, or use the setwd() command to state the working directory. If you use RStudio, click on "Session" then "Set Working Directory". 

The remaining 6 R-code files (which could be run separately from each other) are:

general.R Draws Figure 1 in Section 2. It also draw some histograms that do not appear in the paper. 

tree.R Draws the classification tree Figure 2 in Section 3.1. It also builds the confusion matrix displayed in Table 1(a). 

logit.R Runs the binomial logit regression in Section 3.2 and generates the marginal effects displayed in Table 2. 

multinom.R Runs multinomial logit in Section 3.3 and generates the confusion matrix in Table 1(b). 

forest.R Runs the random forest algorithm in Section 4. It generates the Variable Importance Plot displayed in Figure 3, and the confusion matrix in Table 1(c). 

knn.R Runs the k-nearest neighbors analysis in Section 5, draws Figure 4, and generats the confusion matrix in Table 1(d).

neural.R Runs the neural network analysis in Section 6, draws Figure 5, and generates the confusion matrix in Table 3(e). 

*** End of read_me_first.txt *** 

