# logit.R Section 3.2 (Binomial logit, Table 2)
# Revised 180513
# Packages used for this coding: 
library("xtable") #exporting to LaTeX
library(mfx) # logit regressions with marginal effects
# library(margins) # Not used here, also complutes marginal effects
library(plyr)# To "join" two dataframe (instead of "merge" that reorders the rows)
library("DescTools")# Needed only for Pseudo-R2 (for glm)
library("stats") # Needed for predict.glm
#
setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding") # Set working directory on your computer
# Your working directory would be different from the above !!!
dir()
diary=readRDS("diary2016_data.rds")# read edited data
dim(diary)
names(diary)
str(diary)
# I need to delete transaction with methods used less than 1%
100*round(table(diary$Method)/length(diary$Method), digits = 4) #percent
# Choose the 5 most widely used payment methods (> 1% use)
diary=diary[diary$Method=="Cash" | diary$Method=="Ccard" 
            | diary$Method=="Dcard" | diary$Method=="Pcard" | diary$Method=="Check", ]
dim(diary)# 
table(diary$Method)# still need to remove the attributes of unused payment methods
diary$Method = factor(diary$Method)# This removes unused factor levels of deleted Methods
str(diary$Method)
table(diary$Method)
#
# Need to define new binary columns for "Cash" "Ccard" "Dcard" "Pcard" "Check
diary$Cash = NA # create a binary "Cash" column
diary$Cash[diary$Method == "Cash"] = 1
diary$Cash[diary$Method != "Cash"] = 0
table(diary$Cash)
# diary$Ccard = NA # create a binary "Ccard" column
# diary$Ccard[diary$Method == "Ccard"] = 1
# diary$Ccard[diary$Method != "Ccard"] = 0
# table(diary$Ccard)
# diary$Dcard = NA # create a binary "Dcard" column
# diary$Dcard[diary$Method == "Dcard"] = 1
# diary$Dcard[diary$Method != "Dcard"] = 0
# table(diary$Dcard)
# diary$Pcard = NA # create a binary "Pcard" column
# diary$Pcard[diary$Method == "Pcard"] = 1
# diary$Pcard[diary$Method != "Pcard"] = 0
# table(diary$Pcard)
# diary$Pcard = NA # create a binary "Check" column
# diary$Pcard[diary$Method == "Check"] = 1
# diary$Pcard[diary$Method != "Check"] = 0
# table(diary$Check)
#
# Defining regression models (for logistic estimation): 
cash_on_demog = Cash~Amount+Age+HH_size+Work+Marital+HH_income+House+Gender+Race # Educ removed
#
# Getting marginal effects at means (T is default). 
# Set F for average marginal effects (I checked, not much difference)
cash_mfx = logitmfx(cash_on_demog, data = diary, atmean = T)  
cash_mfx
names(cash_mfx)
cash_mfx$mfxest # table of marginal effects 
(cash_xt=as.data.frame(cash_mfx$mfxest))
dim(cash_xt)#I see 5 columns not 4 (b/c 1st column is rownames)
names(cash_xt)
#
# Below, fix a problem that ***, **, * do not appear => need to add column)
for (i in 1:nrow(cash_xt)){cash_xt[i,5]=' '}
for (i in 1:nrow(cash_xt)){
  if(cash_xt[i,4]<=0.05){cash_xt[i,5]='*'}
}
for (i in 1:nrow(cash_xt)){
  if(cash_xt[i,4]<=0.01){cash_xt[i,5]='**'}
}
for (i in 1:nrow(cash_xt)){
  if(cash_xt[i,4]<=0.001){cash_xt[i,5]='***'}
}
cash_xt # This table has a new column with *, **, and ***
#
# Introducing 4 dummies: (motivated by the tree)
diary$d_amt10 = 0
diary$d_amt10[diary$Amount > 10] = 1 # transaction value more than $10
diary$d_amt20 = 0
diary$d_amt20[diary$Amount > 20] = 1 # transaction value more than $10
diary$d_age36 = 0
diary$d_age36[diary$Age > 36 & diary$Age <=64 ] =1
diary$d_age64 = 0
diary$d_age64[diary$Age > 64] = 1
head(diary)
tail(diary)
#
# Below, binomial model with dummies included (Educ removed)
cash_on_demog_d = Cash~Amount+Age+HH_size+Work+Marital+HH_income+
  House+Gender+Race+d_amt10+d_amt20+d_age36+d_age64
cash_mfx_d=logitmfx(cash_on_demog_d, data = diary)
cash_mfx_d
names(cash_mfx_d)
cash_mfx_d$mfxest # table of marginal effects ( Problem the ***, **, * do not appear => need to add column)
(cash_xt_d=as.data.frame(cash_mfx_d$mfxest))
dim(cash_xt_d)#I see 5 columns not 4?
names(cash_xt_d)
# Adding a column with significance *, **, ***
for (i in 1:nrow(cash_xt_d)){cash_xt_d[i,5]=' '}
for (i in 1:nrow(cash_xt_d)){
  if(cash_xt_d[i,4]<=0.05){cash_xt_d[i,5]='*'}
}
for (i in 1:nrow(cash_xt_d)){
  if(cash_xt_d[i,4]<=0.01){cash_xt_d[i,5]='**'}
}
for (i in 1:nrow(cash_xt_d)){
  if(cash_xt_d[i,4]<=0.001){cash_xt_d[i,5]='***'}
}
cash_xt_d # This table has *, **, ***
#xtable(cash_xt_d, digits = c(0,3,3,3,3,0))
#
# Combining two tables: cash_xt (w/o dummies) and cash_xt_d (w/ dummies, 2 rows longer)
names(cash_xt)
names(cash_xt_d)
colnames(cash_xt)[colnames(cash_xt) == "dF/dx"] = "Marg_eff"
colnames(cash_xt)[colnames(cash_xt) ==  "V5"] = "Sig"
colnames(cash_xt_d)[colnames(cash_xt_d) == "dF/dx"] = "Marg_eff_d"
colnames(cash_xt_d)[colnames(cash_xt_d) ==  "V5"] = "Sig_d"
dim(cash_xt)
dim(cash_xt_d)# Notice that this df is longer by 4 lines (4 dummies)
# 
# Now, merge cash_xt with cash_xt_d (adds 4 dummies)
# Need to find a way to preserve the order of the rows (merge changes it)
names(cash_xt)
rownames(cash_xt)
cash_xt2 = cash_xt
cash_xt2$Variable = rownames(cash_xt) # Making rownames a column called "Variable"
names(cash_xt2)
cash_xt2 = cash_xt2[, c("Variable", "Marg_eff", "Sig")]
names(cash_xt2)
row.names(cash_xt2) = NULL # Remove row names (now under the Variable column)
cash_xt2
#
# Do the same as above to the regression with add'l 4 dummies
names(cash_xt_d)
rownames(cash_xt_d)
cash_xt_d2 = cash_xt_d
cash_xt_d2$Variable = rownames(cash_xt_d) # Making rownames a column called "Variable"
names(cash_xt_d2)
cash_xt_d2 = cash_xt_d2[, c("Variable", "Marg_eff_d", "Sig_d")]
names(cash_xt_d2)
row.names(cash_xt_d2) = NULL # Remove row names (now under the Variable column)
cash_xt_d2
#
# cash_xt_merge =  merge(cash_xt2, cash_xt_d2, by = "Variable", all.y = T)# y means 2nd df: cash_xt_d2
# Problem above: Merge changes row order (levels of the Variable) => use "join" {plyr} package
dim(cash_xt2)
dim(cash_xt_d2)
cash_xt_merge =  join(cash_xt_d2, cash_xt2, by = "Variable")
dim(cash_xt_merge)
cash_xt_merge
names(cash_xt_merge)
#
print(xtable(cash_xt_merge, digits = 4), include.rownames = FALSE) # This removes row numbers
str(cash_xt_merge)
#
# Checking whether adding dummies increases fit (AIC and pseudo-R2)
cash_glm = glm(cash_on_demog, data = diary, family = binomial(link = "logit"))
summary(cash_glm)
PseudoR2(cash_glm)
cash_glm_d = glm(cash_on_demog_d, data = diary, family = binomial(link = "logit"))
summary(cash_glm_d)
PseudoR2(cash_glm_d)

### End of Logit 

