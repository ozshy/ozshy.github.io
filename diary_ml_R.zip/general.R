# general.R Drawing Figure 1 in Section 2 (full version of the paper only)
#Revised 180513
# Libraries used
library(ggplot2)
library(cowplot) # acts line par(mfrow() which does not work with ggplot)
#
setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding") # Set working directory on your computer
# Your working directory would be different from the above !!!
#
dir()
diary=readRDS("diary2016_data.rds") # Read edited data file
dim(diary)
names(diary)
str(diary)
table(diary$Method) # discuss this in the paper
# I need to delete transaction with methods used less than 1%
100*round(table(diary$Method)/length(diary$Method), digits = 4) #percent
# Choose the 5 most widely used payment methods (> 1% use)
diary=diary[diary$Method=="Cash" | diary$Method=="Ccard" 
            | diary$Method=="Dcard" | diary$Method=="Pcard" | diary$Method=="Check", ]
dim(diary)# losing only 78 transactions
table(diary$Method)# still need to remove the attributes of unused payment methods
diary$Method = factor(diary$Method)# This removes unused factor levels of deleted Methods
str(diary$Method)
table(diary$Method)
#
# Draw Methods on Amount with different colors. Figure 1 in the paper
plot(Method~Amount, data = subset(diary, diary$Amount<=100), col=rainbow(5),
     ylab = "Method of payment (Method)", xlab="Transaction dollar value (Amount)",
     axes=T, breaks = seq(0, 100, 5)) # generates $5 bin sizes 
#Axis(side=1, labels = T)
#Axis(side=2, labels = T)
legend("bottomleft", c("Cash","Credit card", "Debit card", "Prepay card", "Check"),
       fill=rainbow(5))
#
# Number of payments in each bin of Figure 1 in the paper
length(which(diary$Amount>0 & diary$Amount<=5))
length(which(diary$Amount>5 & diary$Amount<=10))
length(which(diary$Amount>10 & diary$Amount<=15))
length(which(diary$Amount>20 & diary$Amount<=30))
length(which(diary$Amount>30 & diary$Amount<=40))
length(which(diary$Amount>40 & diary$Amount<=50))
length(which(diary$Amount>50 & diary$Amount<=60))
length(which(diary$Amount>60 & diary$Amount<=70))
length(which(diary$Amount>70 & diary$Amount<=80))
length(which(diary$Amount>80 & diary$Amount<=90))
length(which(diary$Amount>95 & diary$Amount<=100))
#
### End of genereal data analysis

### Analysis below is Not in the paper ###
# Below, compare histograms of different methods w.r.t Amount 
# to verify have different distributions w.r.t. Amount and age
head(diary)
table(diary$Method)
cash.sub = subset(diary, diary$Method == "Cash")
cash.sub = subset(cash.sub, cash.sub$Amount<=100)
head(cash.sub)
# 
ccard.sub = subset(diary, diary$Method == "Ccard")
ccard.sub = subset(ccard.sub, ccard.sub$Amount<=100)
head(ccard.sub)
# 
dcard.sub = subset(diary, diary$Method == "Dcard")
dcard.sub = subset(dcard.sub, dcard.sub$Amount<=100)
head(dcard.sub)
#
check.sub = subset(diary, diary$Method == "Check")
check.sub = subset(check.sub, check.sub$Amount<=100)
head(check.sub)
#
pcard.sub = subset(diary, diary$Method == "Pcard")
pcard.sub = subset(pcard.sub, pcard.sub$Amount<=100)
head(pcard.sub)
#
# par(mfrow = c(3,2))
hist(cash.sub$Amount, freq = F) # Cash histogram
hist(ccard.sub$Amount, freq = F) # Credit card histogram
hist(dcard.sub$Amount, freq = F) # Debit card histogram
hist(pcard.sub$Amount, freq = F) # Prepaid card histogram
hist(check.sub$Amount, freq = F) # Check histogram
#
# Same histrograms using ggplot2
cash.gg = ggplot(cash.sub, aes(cash.sub$Amount)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Payment dollar amount", y = "Number of payments")
#
ccard.gg = ggplot(ccard.sub, aes(ccard.sub$Amount)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Payment dollar amount", y = "Number of payments")
#
dcard.gg = ggplot(dcard.sub, aes(dcard.sub$Amount)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Payment dollar amount", y = "Number of payments")
#
pcard.gg = ggplot(pcard.sub, aes(pcard.sub$Amount)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Payment dollar amount", y = "Number of payments")
#
check.gg = ggplot(check.sub, aes(check.sub$Amount)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Payment dollar amount", y = "Number of payments")
# Below, package cowplot is used
plot_grid(cash.gg, ccard.gg, dcard.gg, pcard.gg, check.gg,
        ncol = 2, nrow = 3,
        labels = c("Cash          ", "Credit card  ", "Debit card   "
                   , "Prepaid card", "Check          "),
        vjust = 3, hjust = -1.9, label_size = 12)
#
# Start histograms w.r.t. Age
cash.gg = ggplot(cash.sub, aes(cash.sub$Age)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Age", y = "Number of payments")
#
ccard.gg = ggplot(ccard.sub, aes(ccard.sub$Age)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Age", y = "Number of payments")
#
dcard.gg = ggplot(dcard.sub, aes(dcard.sub$Age)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Age", y = "Number of payments")
#
pcard.gg = ggplot(pcard.sub, aes(pcard.sub$Age)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Age", y = "Number of payments")
#
check.gg = ggplot(check.sub, aes(check.sub$Age)) + 
  geom_histogram(col="black", fill = "blue", alpha = 0.5, bins = 20) + 
  labs(x = "Age", y = "Number of payments")
# Below, package cowplot is used
plot_grid(cash.gg, ccard.gg, dcard.gg, pcard.gg, check.gg,
          ncol = 2, nrow = 3,
          labels = c("Cash          ", "Credit card  ", "Debit card   "
                     , "Prepaid card", "Check          "),
          vjust = 3, hjust = -1.9, label_size = 12)
