# neural.R adding a section starting diary_ml_17.tex 181111
# Revised 180519
# library(ggplot2) # for plotting 
# theme_set(theme_bw())# White background for plots 
library(neuralnet) #for neural networks
library(xtable) # converts tables to LaTeX
#
setwd("C:/Users/Oz/Papers/diary-ml/diary-ml-coding") # Set working directory on your computer
# Your working directory would be different from the above !!!
dir()
diary=readRDS("diary2016_data.rds")# read edited data
dim(diary)
names(diary)
str(diary)
# I need to delete transaction with methods used less than 1%
100*round(table(diary$Method)/length(diary$Method), digits = 4) #percent
#
# Choose the 5 most widely used payment methods (> 1% use)
# Now limit payment methods to Cash, Ccard, and Dcard
diary = diary[diary$Method=="Cash" | diary$Method=="Ccard" | diary$Method=="Dcard" | diary$Method=="Pcard" | diary$Method=="Check", ]
diary$Method = factor(diary$Method) # Deletes unused factors
table(diary$Method) # transactions
100*round(prop.table(table(diary$Method)), digits = 4) #pecents
#
# neuralnet (knn and clustering) work with numerical features (not factors)
# Below, convert HH_income to numerical values by taking the average in each category
table(diary$HH_income)
# Below, refers to the reduced income categories: diary2016sm.rds
# Create a new feature (column) called "Income"
diary$Income = 0
diary$Income[diary$HH_income == "0<25k"]    = 12500
diary$Income[diary$HH_income == "25<50k"]   = 37500
diary$Income[diary$HH_income == "50<75k"]   = 62500
diary$Income[diary$HH_income == "75<100k"]  = 87500
diary$Income[diary$HH_income == "100<125k"] = 112500
diary$Income[diary$HH_income == "125<200k"] = 162500
diary$Income[diary$HH_income == "200<500k"] = 350000
diary$Income[diary$HH_income == ">500k"]    = 500000
#
# Reduce the number of features numerical valued only  
str(diary)
# neuralnet package does not work with categorical features
# delete features that are factors (leave method as the dependent variable)
n = subset(diary, select = c("Method", "Amount", "HH_size", "Age", "Income"))
str(n)
head(n)

# expand methods (factors) to binary columns (neuralnet cannot work with factors)
table(n$Method)
n$Cash = ifelse(n$Method == "Cash", 1, 0) # add binary column: Cash
n$Ccard = ifelse(n$Method == "Ccard", 1, 0)
n$Dcard = ifelse(n$Method == "Dcard", 1, 0)
n$Pcard = ifelse(n$Method == "Pcard", 1, 0)
n$Check = ifelse(n$Method == "Check", 1, 0)
table(n$Method) # verify new columns match column Medhod
sum(n$Cash)
sum(n$Ccard)
sum(n$Dcard)
sum(n$Pcard)
sum(n$Check)

#scale features (inputs) using min-max normalization ==> [0,1]
normalize = function(x) {
  return((x - min(x))/(max(x) -  min(x)))
}
n$Amount_norm = normalize(n$Amount)
n$HH_size_norm = normalize(n$HH_size)
n$Age_norm = normalize(n$Age)
n$Income_norm = normalize(n$Income)

# Splitting n into training and testing 
set.seed(1) # Same seed as other parts the paper
index_train = sample(1:nrow(n), size=0.8*nrow(n), replace = F)
length(index_train) 
n_train = n[index_train, ]# 80% of diarym
n_test = n[-index_train, ]# 20% of diarym
#
head(n_train)
head(n_test)
dim(n_train)
dim(n_test)
nrow(n_train) + nrow(n_test) # Sample size

### neural fit model begins
names(n_train)
# below, hidden = c(2), b/c c(3) & c(4) did not converge
# c(2) ==> 1st layer has 2 neurons c(3,2) means 1st has 3, 2nd has 2, etc.
# 1 hidden layer is sufficient for most datasets. No. layers is generally the mean of input and output layers (4 or 5 in this case)
# Below, I run 1 hidden layer with 1, 2, 3, 4 neurons. Some may not converge, so try again and again. 

# 1 neuron # took 14.8 seconds, always converged
start_time = Sys.time()
n_fit_1 = neuralnet(Cash + Ccard + Dcard + Pcard + Check ~ Amount_norm + HH_size_norm + Age_norm + Income_norm, data = n_train, hidden = c(1), linear.output=FALSE)
end_time = Sys.time()
(time_n_fit_1 = end_time - start_time)

# 2 neurons # took 57 seconds, NOT always converge, try again
start_time = Sys.time()
n_fit_2 = neuralnet(Cash + Ccard + Dcard + Pcard + Check ~ Amount_norm + HH_size_norm + Age_norm + Income_norm, data = n_train, hidden = c(2), linear.output=FALSE)
end_time = Sys.time()
(time_n_fit_2 = end_time - start_time)

# 3 neurons # took 3.89 minutes, NOT always converge, try again
start_time = Sys.time()
n_fit_3 = neuralnet(Cash + Ccard + Dcard + Pcard + Check ~ Amount_norm + HH_size_norm + Age_norm + Income_norm, data = n_train, hidden = c(3), linear.output=FALSE)
end_time = Sys.time()
(time_n_fit_3 = end_time - start_time)

# 4 neurons # took 5.7 minutes, NOT always converge, try again
start_time = Sys.time()
n_fit_4 = neuralnet(Cash + Ccard + Dcard + Pcard + Check ~ Amount_norm + HH_size_norm + Age_norm + Income_norm, data = n_train, hidden = c(4), linear.output=FALSE)
end_time = Sys.time()
(time_n_fit_4 = end_time - start_time)

# 5 neurons # took 9.3 minutes, did NOT converge!
start_time = Sys.time()
n_fit_5 = neuralnet(Cash + Ccard + Dcard + Pcard + Check ~ Amount_norm + HH_size_norm + Age_norm + Income_norm, data = n_train, hidden = c(5), linear.output=FALSE)
end_time = Sys.time()
(time_n_fit_5 = end_time - start_time)

#plotting below
plot(n_fit_1)
plot(n_fit_2)
plot(n_fit_3)
plot(n_fit_4) 
#plot(n_fit_5) did NOT converge

# Final picture (removing bottom text)
plot(n_fit_4, information = F)

### Start confusion matrix for neural w/ 5 payment methods (to be added to table 1, or different table)
n_test_features = subset(n_test, select = c("Amount_norm", "HH_size_norm", "Age_norm", "Income_norm")) # used features only
pred_raw_list = compute(n_fit_4, n_test_features) # neuralnet predict uses compute
pred_weights = pred_raw_list$net.result # extract the weights placed on each payment method
str(pred_weights)
head(pred_weights)
idx <- apply(pred_weights, 1, which.max) # by row, which method (column) has the highest weight
tail(idx)
str(idx)
summary(idx) # seems that there are zero predictions for methods 4 & 5 (Pcard & Check)

pred = c("Cash", "Ccard", "Dcard", "Pcard", "Check")[idx] # Trick how to get the predicted method for each test obs
head(pred)
str(pred)

n_table = table(pred, n_test$Method, dnn = c("Predicted", "Actual"))
str(n_table)
n_table = rbind(n_table, 0) # adding missing rows for Pcard & Check where have zero predictions
n_table = rbind(n_table, 0)
n_table
dim(n_table)
rownames(n_table)
rownames(n_table) = c("Cash", "Ccard", "Dcard", "Pcard", "Check")
rownames(n_table)
#
# Table to be appended below the confusion table (neural)
method_demog_error = data.frame("Cash" = c(NA,NA,NA), "Ccard" = c(NA,NA,NA), "Dcard" = c(NA,NA,NA), "Pcard" = c(NA,NA,NA), "Check" = c(NA,NA,NA))
row.names(method_demog_error) = c("Total actual", "Correct predictions", "Correct rate (%)")
# 1st row: Total actual
(method_demog_error[1, "Cash"]  = length(n_test$Method[n_test$Method == "Cash"]))# Actual cash trans
(method_demog_error[1, "Ccard"] = length(n_test$Method[n_test$Method == "Ccard"]))# Actual Ccard trans
(method_demog_error[1, "Dcard"] = length(n_test$Method[n_test$Method == "Dcard"]))# Actual Dcard trans
(method_demog_error[1, "Pcard"] = length(n_test$Method[n_test$Method == "Pcard"]))# Actual Pcard trans
(method_demog_error[1, "Check"] = length(n_test$Method[n_test$Method == "Check"]))# Actual Check trans
# 2nd row: No. correct predictions (%) [true positive rate]
(method_demog_error[2, "Cash"] =   n_table[1,1])
(method_demog_error[2, "Ccard"] =  n_table[2,2])
(method_demog_error[2, "Dcard"] =  n_table[3,3])
(method_demog_error[2, "Pcard"] =  n_table[4,4])
(method_demog_error[2, "Check"] =  n_table[5,5])
# 3rd row: Correct predictions (%) [true positive rate]
(method_demog_error[3, "Cash"] =   100*n_table[1,1]/method_demog_error[1, "Cash"])
(method_demog_error[3, "Ccard"] =  100*n_table[2,2]/method_demog_error[1, "Ccard"])
(method_demog_error[3, "Dcard"] =  100*n_table[3,3]/method_demog_error[1, "Dcard"])
(method_demog_error[3, "Pcard"] =  100*n_table[4,4]/method_demog_error[1, "Pcard"])
(method_demog_error[3, "Check"] =  100*n_table[5,5]/method_demog_error[1, "Check"])
#
round(method_demog_error, digits = 0) # To be appended to the bottom of the confusion matrix
#
# Converting the above 2 tables to LaTeX:
xtable(n_table, digits = 0) # confusion table
xtable(method_demog_error, digits = 0) # Stats to append at the bottom of confusion table
#
### End of neural networks R code ###

